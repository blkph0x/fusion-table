package au.mealplanner.domain

import au.mealplanner.domain.shopping.CatalogueProduct
import au.mealplanner.domain.shopping.ProductMatcher
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CatalogueIdentityTest {
    private fun product(name: String) = CatalogueProduct(name, 500L, "500g", true, true, null)
    private fun selected(query: String, name: String, pack: String = "500g") = ProductMatcher.match(query, listOf(product(name).copy(packageSize = pack))).any { it.selected }
    private fun excluded(query: String, name: String, pack: String = "500g") = assertTrue("$query must exclude $name", ProductMatcher.match(query, listOf(product(name).copy(packageSize = pack))).isEmpty())

    @Test
    fun animalMinceCannotUsePlantBasedSubstitutes() {
        excluded("Beef mince", "Plant Based Beef Mince")
        excluded("Raw beef mince", "Plant Based Beef Mince 500g")
        excluded("Chicken mince", "Meat Free Chicken Mince")
        excluded("Plant Based Beef Mince", "Raw Beef Mince")
        excluded("Beef mince", "Quorn Mince")
        excluded("Plant based mince", "Quorn Mince")
        excluded("Vegan mince", "Vegetarian Mince")
        assertTrue(selected("Beef mince", "Lean Beef Mince 500g"))
        assertTrue(selected("Plant Based Beef Mince", "Plant Based Beef Mince 500g"))
        assertTrue(selected("Plant based mince", "Plant Based Beef Mince"))
        assertTrue(selected("Vegan mince", "Vegan Plant Based Mince"))
        assertTrue(selected("Angus beef mince", "Angus Mince"))
    }

    @Test
    fun butterAndDairyKeepTheirActualFoodType() {
        excluded("Unsalted butter", "Organic Peanut Butter Unsalted")
        excluded("Butter", "Peanut Butter Smooth")
        excluded("Milk", "Soy Milk")
        excluded("Cooking cream", "Coconut Cooking Cream")
        excluded("Almond milk", "Oat Milk")
        excluded("Vegan butter", "Vegan Peanut Butter")
        assertTrue(selected("Unsalted butter", "Unsalted Butter Block"))
        assertTrue(selected("Peanut butter", "Organic Peanut Butter Smooth"))
        assertTrue(selected("Almond milk", "Unsweetened Almond Milk"))
        assertTrue(selected("Coconut cooking cream", "Coconut Cooking Cream"))
        assertTrue(selected("Vegan butter", "Vegan Butter Spread"))
        assertTrue(selected("Dairy-free butter", "Dairy Free Butter Spread"))
        assertTrue(selected("Lactose-free milk", "Lactose Free Full Cream Milk"))
    }

    @Test
    fun cookedAndDeliPoultryCannotPriceRawBreast() {
        for (name in listOf("Cooked Chicken Breast Fillets", "Carved Roast Chicken Breast", "Shredded Chicken Breast Deli Slices", "Shredded Roast Chicken", "Chicken Breast Thinly Sliced")) excluded("Chicken breast", name)
        assertTrue(selected("Chicken breast", "Fresh Chicken Breast Fillets"))
        assertTrue(selected("Chicken breast", "Raw Chicken Breast Slices For Stir Fry"))
        assertTrue(selected("Cooked chicken breast", "Carved Roast Chicken Breast Deli Slices"))
        assertTrue(selected("Cooked chicken breast", "Cooked Chicken Breast Fillets"))
    }

    @Test
    fun aWholePoultryCutDoesNotProveARoastIsRaw() {
        excluded("Whole chicken", "Hot Roast Whole Chicken")
        excluded("Whole chicken", "Roast Whole Chicken")
        excluded("Whole turkey", "Whole Turkey Roast")
        excluded("Whole chicken", "Fresh Hot Roast Whole Chicken")
        excluded("Whole turkey", "Fresh Hot Whole Turkey Roast")
        excluded("Chicken breast", "Fresh Carved Roast Chicken Breast")
        assertTrue(selected("Whole chicken", "Fresh Whole Chicken"))
        assertTrue(selected("Whole chicken", "Fresh Roasting Whole Chicken"))
        assertTrue(selected("Whole turkey", "Whole Turkey For Roasting"))
        assertTrue(selected("Whole turkey", "Raw Whole Turkey Roast"))
        assertTrue(selected("Cooked whole turkey", "Whole Turkey Roast"))
        assertTrue(selected("Cooked whole chicken", "Fresh Hot Roast Whole Chicken"))
    }

    @Test
    fun rawRoastingCutsAndExplicitPreparedFoodsRemainAvailable() {
        assertTrue(selected("Beef bolar roast", "Beef Bolar Roast"))
        assertTrue(selected("Pork leg roast", "Pork Leg Roast"))
        assertTrue(selected("Chicken breast", "Chicken Breast Roasting Joint"))
        assertTrue(selected("Chicken stock", "Roast Chicken Stock"))
        excluded("Chicken breast", "Crumbed Chicken Breast Schnitzel")
        assertTrue(selected("Crumbed chicken breast schnitzel", "Crumbed Chicken Breast Schnitzel"))
        assertTrue(selected("Smoked chicken breast", "Smoked Chicken Breast Slices"))
    }

    @Test
    fun anIngredientHeadCannotBeLostAmongQuantityTokens() {
        excluded("Brown onion 180g", "Brown Rice 1kg")
        excluded("Brown onion", "Brown Rice")
        assertTrue(selected("Brown onion 180g", "Brown Onion Loose"))
        assertTrue(selected("Brown onion 180 g", "Brown Onions"))
        assertTrue(selected("Fresh coriander", "Fresh Coriander"))
        assertTrue(selected("Beef sirloin", "Porterhouse Steak"))
    }

    @Test
    fun aromaticsAndProduceCannotBeReplacedByFinishedFoodsOrPreparedJars() {
        excluded("Fresh ginger", "Stem Ginger Cookies")
        excluded("Fresh ginger", "Stem Ginger Biscuits")
        excluded("Fresh garlic", "Garlic Bread")
        excluded("Fresh basil", "Basil Pesto")
        excluded("Tomatoes", "Tomato Relish")
        excluded("Lime juice", "Lime Juice Cordial")
        excluded("Fresh ginger", "Ginger Beer")
        excluded("Fresh ginger", "Ginger In Syrup")
        excluded("Fresh ginger", "Buderim Ginger Australian Ready Cut")
        excluded("Fresh ginger", "Jensens Crushed Ginger")
        excluded("Fresh ginger", "MasterFoods Finely Chopped Ginger")
        assertTrue(selected("Fresh ginger", "Fresh Chopped Ginger"))
        assertTrue(selected("Garlic", "Fresh Garlic Cloves"))
        assertTrue(selected("Crushed ginger", "Jensens Crushed Ginger"))
        assertTrue(selected("Chopped ginger", "MasterFoods Finely Chopped Ginger"))
    }

    @Test
    fun explicitlyRequestedPreparedFoodsSeedsAndFoodFormsRemainAvailable() {
        assertTrue(selected("Ginger cookies", "Stem Ginger Cookies"))
        assertTrue(selected("Garlic bread", "Garlic Butter Bread"))
        assertTrue(selected("Basil pesto", "Basil Pesto"))
        assertTrue(selected("Lime juice cordial", "Lime Juice Cordial"))
        assertTrue(selected("Ginger beer", "Ginger Beer"))
        assertTrue(selected("Ground ginger", "Ground Ginger"))
        assertTrue(selected("Garlic paste", "Garlic Paste"))
        assertTrue(selected("Sesame seeds", "Sesame Seeds"))
        assertTrue(selected("Coriander seeds", "Coriander Seeds"))
        assertTrue(selected("Cream of tartar", "Cream Of Tartar"))
        assertTrue(selected("Arborio risotto rice", "Arborio Risotto Rice"))
    }

    @Test
    fun clearNonFoodListingsCannotPriceIngredientsButCulinarySeedsAndOilsStayAvailable() {
        excluded("Fresh ginger", "Dr Scent Ginger Lemongrass Aroma Oil - Fresh Strong Herbal - Waterless Diffuser Oil 1000ml")
        excluded("Spring onions", "Yates Spring Onions Seeds")
        excluded("Spring onions", "Stainless Steel Cutter Gadget Scallion Vegetable Spring Onion Slicer")
        excluded("Coconut oil", "Coconut Hair Oil")
        excluded("Milk", "Milk Body Lotion")
        excluded("Chicken", "Chicken Dog Food")
        excluded("Coriander seeds", "Coriander Seeds For Planting")
        excluded("Chicken", "Chicken Wire Mesh")
        assertTrue(selected("Sesame seeds", "Sesame Seeds"))
        assertTrue(selected("Coriander seeds", "Coriander Seeds"))
        assertTrue(selected("Pumpkin seeds", "Pumpkin Seeds"))
        assertTrue(selected("Spring onions", "Fresh Spring Onions Bunch"))
        assertTrue(selected("Olive oil", "Extra Virgin Olive Oil"))
        assertTrue(selected("Coconut oil", "Virgin Coconut Oil"))
    }

    @Test
    fun sweetPotatoAndOrdinaryPotatoesKeepTheirIdentity() {
        excluded("Potatoes", "Sweet Potatoes")
        excluded("White potatoes", "Sweet Potatoes")
        excluded("Sweet potatoes", "White Potatoes")
        assertTrue(selected("Potatoes", "White Potatoes"))
        assertTrue(selected("Potatoes", "Baby Potatoes"))
        assertTrue(selected("Sweet potatoes", "Sweet Potatoes"))
    }

    @Test
    fun compoundButtersCannotReplacePlainButterOrLoseTheirFlavours() {
        excluded("Unsalted butter", "Unsalted Garlic Butter")
        excluded("Butter", "Herb Butter")
        excluded("Garlic butter", "Butter Block")
        excluded("Herb butter", "Butter Block")
        excluded("Garlic butter", "Garlic And Herb Butter")
        assertTrue(selected("Butter", "Unsalted Butter Block"))
        assertTrue(selected("Garlic butter", "Garlic Butter"))
        assertTrue(selected("Herb butter", "Herb Butter"))
        assertTrue(selected("Garlic and herb butter", "Garlic And Herb Butter"))
        assertTrue(selected("Garlic bread", "Garlic Butter Bread"))
        assertTrue(selected("Peanut butter", "Peanut Butter Smooth"))
        assertTrue(selected("Vegan butter", "Vegan Butter Spread"))
    }

    @Test
    fun gingerFlavouredBreadCompoundsCannotPriceFreshGinger() {
        excluded("Fresh ginger", "CURATED COLLECTION Gluten Free Fig and Ginger Crispbread 150g")
        excluded("Fresh ginger", "Gingerbread")
        excluded("Fresh ginger", "Ginger Shortbread")
        assertTrue(selected("Gingerbread biscuits", "Gingerbread Biscuits"))
        assertTrue(selected("Fresh ginger", "Fresh Ginger Root"))
    }

    @Test
    fun poultryFilletsCannotUseBuffeCrownOrUnrequestedSelfBastingPreparations() {
        for (name in listOf("Ingham's Frozen Buffe Turkey Breast Self Basting", "Turkey Breast Crown", "Turkey Breast Buffet", "Self Basting Turkey Breast Fillets", "Self Basted Turkey Breast Fillets", "Injected Turkey Breast Fillets")) {
            excluded("Turkey breast fillets", name)
        }
        excluded("Chicken breast fillets", "Chicken Breast Crown")
        assertTrue(selected("Turkey breast fillets", "Fresh Turkey Breast Fillets"))
        assertTrue(selected("Self basting turkey breast", "Brand Self Basting Turkey Breast"))
        assertTrue(selected("Self basted turkey breast", "Brand Self Basted Turkey Breast"))
        assertTrue(selected("Turkey breast buffe", "Turkey Breast Buffe"))
        assertTrue(selected("Self basting turkey breast buffe", "Ingham's Frozen Buffe Turkey Breast Self Basting"))
    }

    @Test
    fun turkeyBreastCannotUseTheCapturedDuckBreastProduct() {
        excluded("Turkey breast fillets", "Luv-A-Duck Fresh Duck Breast Fillets")
        assertTrue(selected("Turkey breast fillets", "Fresh Turkey Breast Fillets"))
        assertTrue(selected("Duck breast fillets", "Luv-A-Duck Fresh Duck Breast Fillets"))
    }

    @Test
    fun everyAuthoredMainKeepsItsIdentityAcrossTheOtherTwentyNineMains() {
        val mains = listOf(
            "Chicken breast fillets", "Turkey breast fillets", "Beef rump steak", "Lamb leg steak", "Pork loin steak",
            "Salmon fillets", "White fish fillets", "Raw prawns", "Firm tofu", "Plain tempeh", "Halloumi", "Eggs",
            "Cooked chickpeas", "Cooked green lentils", "Canned butter beans", "Portobello mushrooms", "Aubergine",
            "Cauliflower", "Pumpkin", "Sweet potato", "Courgette", "Broccoli", "Duck breast fillets", "Kangaroo steak",
            "Tuna steak", "Fresh sardines", "Canned black beans", "Canned red kidney beans", "Young jackfruit", "Paneer cheese"
        )
        assertEquals(30, mains.size)
        for (wanted in mains) {
            assertTrue("A plain same-main product must stay available: $wanted", selected(wanted, "Brand $wanted"))
            for (other in mains.filter { it != wanted }) excluded(wanted, "Brand $other")
        }
    }

    @Test
    fun whiteFishUsesOnlyTheAuthoredAliasesAndNamedSpeciesStaySpecific() {
        for (name in listOf("Cod", "Hoki", "Barramundi", "Haddock", "Pollock", "Hake", "Basa")) {
            assertTrue("White fish must allow the authored alias $name", selected("White fish fillets", "$name Fillets"))
            assertTrue(selected("Fish fillets", "$name Fillets"))
        }
        for (name in listOf("Salmon Fillets", "Tuna Fillets", "Sardine Fillets", "Prawn Fillets")) excluded("White fish fillets", name)
        excluded("Cod fillets", "Hoki Fillets")
        excluded("Cod fillets", "White Fish Fillets")
        excluded("Cod fillets", "Fish Fillets")
        excluded("Fish fillets", "Prawn Fillets")
        assertTrue(selected("White fish", "Cod"))
        assertTrue(selected("Cod fillets", "Atlantic Cod Fillets"))
        assertTrue(selected("Prawns", "Raw Shrimp"))
    }

    @Test
    fun namedProteinsCannotBeLostBehindAnUnnamedOrMixedCut() {
        excluded("Turkey breast fillets", "Breast Fillets")
        excluded("Duck breast fillets", "Chicken Breast Fillets")
        excluded("Beef rump steak", "Kangaroo Rump Steak")
        excluded("Beef mince", "Veal Mince")
        excluded("Turkey breast fillets", "Turkey And Duck Breast Fillets")
        excluded("Firm tofu", "Firm Tofu And Tempeh")
        excluded("Plant based beef mince", "Plant Based Chicken Mince")
        assertTrue(selected("Veal mince", "Fresh Veal Mince"))
        assertTrue(selected("Beef mince", "Lean Beef Mince"))
        assertTrue(selected("Tofu", "Bean Curd"))
        assertTrue(selected("Butter beans", "Lima Beans"))
    }

    @Test
    fun brandAndCutWordsDoNotInventAnimalSpecies() {
        assertTrue(selected("Chicken breast fillets", "Luv-A-Duck Fresh Chicken Breast Fillets"))
        excluded("Duck breast fillets", "Luv-A-Duck Fresh Chicken Breast Fillets")
        assertTrue(selected("Beef sirloin", "Porterhouse Steak"))
        assertTrue(selected("Beef scotch fillet", "Cube Roll"))
        assertTrue(selected("Beef oyster blade", "Flat Iron Steak"))
        assertTrue(selected("Oyster blade", "Beef Oyster Blade"))
        assertTrue(selected("Oyster mushrooms", "King Oyster Mushrooms"))
        excluded("Oysters", "Beef Oyster Blade")
        excluded("Oysters", "King Oyster Mushrooms")
    }

    @Test
    fun eggAndDairyNamesDoNotInventMeatSpecies() {
        assertTrue(selected("Eggs", "Free Range Chicken Eggs"))
        excluded("Eggs", "Free Range Duck Eggs")
        excluded("Duck eggs", "Free Range Chicken Eggs")
        excluded("Duck breast", "Duck Eggs")
        assertTrue(selected("Duck eggs", "Free Range Duck Eggs"))
        assertTrue(selected("Quail eggs", "Quail Eggs"))
        assertTrue(selected("Goat milk", "Goat Milk"))
        assertTrue(selected("Milk", "Full Cream Goat Milk"))
        excluded("Goat meat", "Goat Milk")
    }

    @Test
    fun stocksOilsAndTheSquidSauceBrandKeepTheirActualFoodForm() {
        excluded("Salmon fillets", "Salmon Oil")
        excluded("Tofu", "Tofu Oil")
        excluded("Fish oil", "Raw Fish")
        assertTrue(selected("Fish oil", "Fish Oil"))
        assertTrue(selected("Chicken stock", "Roast Chicken Stock"))
        assertTrue(selected("Fish sauce", "Squid Fish Sauce"))
        assertTrue(selected("Fish sauce", "Squid Brand Fish Sauce"))
        excluded("Squid", "Squid Brand Fish Sauce")
    }

    @Test
    fun tortillaFoodCannotBePricedUsingTheCapturedTacoHolder() {
        excluded("Soft tortillas", "JOYBUY Stainless Steel Taco Holders for Soft or Hard Tacos, Burritos and Tortillas (1 Pack)")
        excluded("Tortillas", "Silicone Taco Stand For Tortillas")
        assertTrue(selected("Soft tortillas", "Mission Soft Tortillas"))
        assertTrue(selected("Carrots", "Fresh Carrots Tray"))
    }

    @Test
    fun aSingleFreshCarrotCannotUseMixedFrozenOrRoastVegetablePacks() {
        for (name in listOf(
            "MARKET FARE Carrot, Sweet Corn & Broccoli Quicksteam Vegetables 3 Pack 450g",
            "MARKET FARE Peas, Carrots & Super Sweet Corn 1kg",
            "MARKET FARE Quicksteam Vegetables Carrot, Broccoli & Cauliflower 3 Pack 450g",
            "Birds Eye Country Harvest Carrot Cauliflower Beans & Broccoli",
            "Birds Eye Country Harvest Peas Corn & Carrot",
            "Birds Eye Deli Roast Veggies Potato Pumpkin Onion Carrot",
            "Frozen Carrots"
        )) excluded("Carrot", name)
        excluded("Frozen carrots", "Fresh Carrots")
        assertTrue(selected("Carrots", "Macro Organic Carrots"))
        assertTrue(selected("Carrots", "Woolworths Australian Grown Carrots"))
        assertTrue(selected("Frozen carrots", "Frozen Carrots"))
        assertTrue(selected("Roasted carrots", "Oven Roasted Carrots"))
        assertTrue(selected("Potatoes", "Fresh Roasting Potatoes"))
        assertTrue(selected("Mixed frozen vegetables", "Mixed Frozen Vegetables"))
    }

    @Test
    fun tinyGenericHerbPacksRemainUncertainWithoutFreshFormEvidence() {
        excluded("Coriander leaves for the side", "MasterFoods Coriander Leaves", "5g")
        excluded("Fresh coriander", "MasterFoods Coriander Leaves", "0.005 kg")
        excluded("Basil leaves", "Basil Leaves", "2 x 5g")
        excluded("Parsley leaves", "Parsley Leaves", "5g x 2")
        assertTrue(selected("Fresh coriander", "Fresh Coriander Leaves", "5g"))
        assertTrue(selected("Coriander leaves", "Coriander Leaves Bunch", "5g"))
        assertTrue(selected("Basil leaves", "Living Basil Leaves Pot", "5g"))
        assertTrue(selected("Coriander leaves", "Coriander Leaves", "15g"))
        assertTrue(selected("Dried coriander leaves", "Dried Coriander Leaves", "5g"))
        assertTrue(selected("Coriander seeds", "Coriander Seeds", "5g"))
    }

    @Test
    fun uncertainOrUnavailableStockStillCannotSupplyAnAutomaticPrice() {
        for (candidate in listOf(product("Chicken Breast Fillets").copy(inStock = null, available = null), product("Chicken Breast Fillets").copy(inStock = false, available = false))) {
            val matches = ProductMatcher.match("Chicken breast", listOf(candidate))
            assertEquals(1, matches.size)
            assertFalse(matches.single().selected)
        }
    }

    @Test
    fun capturedPekingDuckCannotReplaceFreshDuckBreast() {
        val peking = CatalogueProduct("LUV-A-DUCK Peking Duck Breast 380g", 1299L, "380g", true, true, null)
        val fresh = CatalogueProduct("Luv-A-Duck Fresh Duck Breast Fillets", 1550L, "380g", true, true, null)
        val matches = ProductMatcher.match("Duck breast fillets", listOf(peking, fresh))
        assertEquals(listOf(fresh.name), matches.map { it.name })
        assertTrue(matches.single().selected)
        assertEquals(1550L, matches.single().priceCents)
    }

    @Test
    fun namedMeatStylesDoNotReplaceRawCutsOrEachOther() {
        for ((query, name) in listOf(
            "Duck breast" to "Confit Duck Breast", "Pork loin" to "Char Siu Pork Loin",
            "Pork loin" to "Chinese BBQ Pork Loin", "Chicken breast" to "Tandoori Chicken Breast",
            "Salmon fillet" to "Teriyaki Salmon Fillet", "Chicken breast" to "Satay Chicken Breast",
            "Turkey breast" to "Peri Peri Turkey Breast", "Beef rump steak" to "Korean BBQ Beef Rump Steak",
            "Teriyaki chicken breast" to "Satay Chicken Breast", "Peking duck breast" to "Confit Duck Breast"
        )) excluded(query, name)
        for (name in listOf("Peking Duck Breast", "Confit Duck Breast", "Char Siu Pork Loin", "Tandoori Chicken Breast", "Teriyaki Salmon Fillet", "Satay Chicken Breast")) {
            assertTrue(name, selected(name, name))
        }
    }

    @Test
    fun readyMeatAndDuckDeliNamesCannotEstablishRawMeat() {
        for ((query, name) in listOf(
            "Duck breast" to "Heat And Eat Duck Breast", "Duck breast" to "Heat And Serve Duck Breast",
            "Duck breast" to "Ready To Heat Duck Breast", "Duck breast" to "Thinly Sliced Duck Breast",
            "Duck breast" to "Roast Duck Breast", "Fresh sardines" to "Smoked Sardines",
            "Hoki fillets" to "Cooked Hoki Fillets", "Quail breast" to "Cooked Quail Breast"
        )) excluded(query, name)
    }

    @Test
    fun rawDuckBrandsPekinBreedAndBarbecueCutsStayUsable() {
        for ((query, name) in listOf(
            "Duck breast" to "Luv-A-Duck Fresh Duck Breast Fillets", "Duck breast" to "Pekin Duck Breast",
            "Duck breast" to "Cherry Valley Fresh Duck Breast", "Duck breast" to "Raw Thinly Sliced Duck Breast",
            "Duck legs" to "Duck Legs For Roasting", "Beef blade steak" to "BBQ Beef Blade Steak",
            "Beef topside roast" to "Beef Topside Roast", "Whole quail" to "Fresh Whole Quail For Roasting"
        )) assertTrue("$query -> $name", selected(query, name))
    }

    @Test
    fun braisedMeatAndRecipeBasePacketsCannotPriceRawLamb() {
        for (name in listOf(
            "Fast Fuel Air Fry Braised Lamb Shanks", "MasterFoods Garlic & Herb Lamb Shanks Slow Cook Recipe Base",
            "McCormick Slow Cooker Garlic & Herb Lamb Shanks Recipe Base", "Lamb Shanks Spice Mix", "Lamb Shanks Seasoning", "Lamb Shanks Simmer Sauce"
        )) excluded("Lamb shanks", name)
        excluded("Beef brisket", "Beef Brisket Dry Rub")
        for ((query, name) in listOf(
            "Lamb shanks" to "Lamb Shanks For Braising", "Beef steak" to "Beef Braising Steak", "Beef steak" to "Beef Stewing Steak",
            "Braised lamb shanks" to "Fast Fuel Air Fry Braised Lamb Shanks",
            "Lamb shanks recipe base" to "MasterFoods Garlic & Herb Lamb Shanks Slow Cook Recipe Base",
            "Beef brisket dry rub" to "Beef Brisket Dry Rub", "Xawaash" to "Xawaash Spice Blend", "Ras el hanout" to "Ras El Hanout Spice Mix"
        )) assertTrue("$query -> $name", selected(query, name))
    }

    @Test
    fun capturedHardFoodMismatchesCannotSurviveAsReviewedRawIngredientCandidates() {
        for ((query, name) in listOf(
            "Boneless skinless salmon fillets" to "Woolworths Frozen Salmon Fillets Skin On",
            "Chicken livers" to "FARMWOOD Chicken Dippers 1kg", "Chicken livers" to "HEALTH & VITALITY Chicken Carbonara 300g",
            "Beef brisket" to "Chief Nutrition Beef Brisket Cheeseburger Bar 40g", "Beef brisket" to "HYDALE Original Beef Jerky 25g",
            "Lamb shanks" to "JULIUS GOLD Dog Meaty Bites Lamb 1kg", "Pork shoulder" to "Primo Roast Pork",
            "Pork shoulder" to "URBAN EATS Pork Dumplings 750g", "Raw peeled, deveined prawns" to "Woolworths Cocktail Prawns Peeled & Deveined",
            "Plain firm tofu" to "Macro Honey Soy Tofu", "Tofu" to "Macro Honey Soy Tofu", "Kangaroo steaks" to "K-Roo Kangaroo Burger",
            "Kangaroo steaks" to "CACHET Premium Kangaroo Chunks for Cats 5 Single Serves 450g",
            "Fresh sardines, gutted and scaled" to "Deep Cove Sardines In Springwater", "Fresh sardines, gutted and scaled" to "Safcol Sardines In Springwater",
            "Paneer" to "MTR Minute Meals Palak Paneer", "Chicken livers" to "Fresh Chicken Breast"
        )) excluded(query, name)
    }

    @Test
    fun explicitlyPreparedFoodsAndMatchingRawLabelsRemainUsable() {
        for ((query, name) in listOf(
            "Raw peeled prawns" to "Raw Cocktail Prawns Peeled", "Cooked cocktail prawns" to "Cooked Cocktail Prawns",
            "Plain firm tofu" to "Plain Firm Soy Tofu", "Honey soy tofu" to "Macro Honey Soy Tofu",
            "Palak paneer" to "MTR Minute Meals Palak Paneer", "Beef jerky" to "HYDALE Original Beef Jerky",
            "Pork dumplings" to "URBAN EATS Pork Dumplings", "Kangaroo burger" to "K-Roo Kangaroo Burger",
            "Sardines in springwater" to "Deep Cove Sardines In Springwater", "Skinless salmon fillets" to "Frozen Skinless Salmon Fillets"
        )) assertTrue("$query -> $name", selected(query, name))
    }

    @Test
    fun plainPlantAndCheeseMainsKeepTheirRequestedFlavour() {
        for (base in listOf("Tofu", "Plain firm tofu", "Tempeh", "Plain soy tempeh", "Paneer", "Halloumi", "Haloumi")) {
            for (flavour in listOf("Smoked", "Tandoori", "Chilli", "Teriyaki", "Satay", "Honey Soy")) {
                val name = "$flavour $base"
                excluded(base, name)
                assertTrue(name, selected(name, name))
            }
        }
        excluded("Teriyaki tofu", "Satay Tofu")
        assertTrue(selected("Tempeh", "Plain Soy Tempeh"))
        assertTrue(selected("Paneer", "Fresh Paneer"))
        assertTrue(selected("Halloumi", "Greek Style Halloumi"))
    }

    @Test
    fun allThirtyAuthoredMainsKeepStrongPreparationExplicit() {
        val mains = listOf("Chicken", "Turkey", "Beef", "Lamb", "Pork", "Salmon", "White fish", "Prawns", "Firm tofu", "Tempeh", "Halloumi", "Eggs", "Chickpeas", "Lentils", "Butter beans", "Mushrooms", "Aubergine / eggplant", "Cauliflower", "Pumpkin", "Sweet potato", "Courgette / zucchini", "Broccoli", "Duck", "Kangaroo", "Tuna", "Sardines", "Black beans", "Kidney beans", "Young jackfruit", "Paneer")
        assertEquals(30,mains.size)
        for (main in mains) for (preparation in listOf("Marinated", "Smoked", "Pickled", "Peking", "Confit", "Char Siu", "Tandoori", "Teriyaki", "Satay", "Honey Soy", "Peri Peri", "Korean BBQ")) {
            val name = "$preparation $main"
            excluded(main,name)
            assertTrue(name,selected(name,name))
        }
        assertTrue(selected("Chickpeas","Canned Chickpeas"))
        assertTrue(selected("Lentils","Cooked Lentils"))
        assertTrue(selected("Black beans","Canned Black Beans"))
        assertTrue(selected("Kidney beans","Cooked Kidney Beans"))
    }
}
