package au.mealplanner.domain.shopping

import au.mealplanner.domain.model.Store
import au.mealplanner.domain.model.StoreChain
import au.mealplanner.domain.planner.Postcodes
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import java.util.Locale

/**
 * Shopping names and catalogue matching.
 * A conflicting cut or breed is not selected. Unknown and out-of-stock rows are not selected.
 * A missing price stays null and is never shown as $0.
 * An online catalogue price is not a local shelf price.
 */
data class MeatCut(
    val id: String,
    val mainId: String,
    val shoppingName: String,
    val group: String,
    val form: String,
    val aliases: List<String> = emptyList()
)

data class FoundShop(
    val name: String,
    val kind: String,
    val detail: String,
    val distanceKm: Double
)

object MeatCuts {
    val all: List<MeatCut> = listOf(
        cut("chicken-breast", "chicken", "Chicken breast fillets", "Everyday", "fillet"),
        cut("chicken-thigh-fillet", "chicken", "Chicken thigh fillets", "Everyday", "fillet"),
        cut("chicken-thigh-bone", "chicken", "Chicken thigh cutlets", "Everyday", "bone-in"),
        cut("chicken-drumstick", "chicken", "Chicken drumsticks", "Everyday", "bone-in"),
        cut("chicken-wing", "chicken", "Chicken wings", "Everyday", "bone-in"),
        cut("chicken-wingette", "chicken", "Chicken wingettes", "Everyday", "bone-in", listOf("chicken wingette", "wing nibbles", "drumettes")),
        cut("chicken-strip", "chicken", "Chicken stir-fry strips", "Everyday", "slice", listOf("chicken strips", "chicken stir fry")),
        cut("chicken-maryland", "chicken", "Chicken marylands", "Everyday", "bone-in"),
        cut("chicken-tenderloin", "chicken", "Chicken tenderloins", "Everyday", "fillet"),
        cut("chicken-mince", "chicken", "Chicken mince", "Everyday", "mince"),
        cut("chicken-whole", "chicken", "Whole chicken", "Less common", "whole"),
        cut("chicken-spatchcock", "chicken", "Spatchcock chicken", "Less common", "whole"),
        cut("chicken-liver", "chicken", "Chicken livers", "Less common", "offal"),
        cut("chicken-heart", "chicken", "Chicken hearts", "Less common", "offal", listOf("chicken heart")),
        cut("chicken-gizzard", "chicken", "Chicken gizzards", "Less common", "offal", listOf("chicken gizzard")),
        cut("chicken-frame", "chicken", "Chicken frames", "Less common", "slow", listOf("chicken frame", "chicken carcass")),
        cut("turkey-breast", "turkey", "Turkey breast fillets", "Everyday", "fillet"),
        cut("turkey-thigh", "turkey", "Turkey thigh fillets", "Everyday", "fillet"),
        cut("turkey-mince", "turkey", "Turkey mince", "Everyday", "mince"),
        cut("turkey-whole", "turkey", "Whole turkey", "Less common", "whole"),
        cut("beef-rump", "beef", "Beef rump steaks", "Everyday", "steak"),
        cut("beef-scotch", "beef", "Beef scotch fillet", "Everyday", "steak", listOf("scotch fillet", "rib eye", "cube roll")),
        cut("beef-sirloin", "beef", "Beef sirloin steaks", "Everyday", "steak"),
        cut("beef-eye-fillet", "beef", "Beef eye fillet", "Everyday", "steak"),
        cut("beef-mince", "beef", "Beef mince", "Everyday", "mince"),
        cut("beef-chuck", "beef", "Boneless beef chuck", "Everyday", "slow"),
        cut("beef-gravy", "beef", "Gravy beef", "Everyday", "slow"),
        cut("beef-oyster", "beef", "Beef oyster blade", "Everyday", "steak", listOf("oyster blade", "flat iron")),
        cut("beef-bolar", "beef", "Beef bolar blade", "Everyday", "steak", listOf("bolar blade")),
        cut("beef-silverside", "beef", "Beef silverside", "Everyday", "slow", listOf("silverside")),
        cut("beef-topside", "beef", "Beef topside", "Everyday", "steak", listOf("topside")),
        cut("beef-tbone", "beef", "Beef T-bone", "Everyday", "steak", listOf("t-bone", "t bone")),
        cut("beef-diced", "beef", "Diced beef", "Everyday", "slow", listOf("beef cubes", "casserole steak")),
        cut("beef-sausage", "beef", "Beef sausages", "Everyday", "slice", listOf("beef sausage")),
        cut("angus-rump", "beef", "Angus beef rump steaks", "Breed", "steak", listOf("angus rump")),
        cut("angus-scotch", "beef", "Angus beef scotch fillet", "Breed", "steak", listOf("angus scotch", "angus rib eye")),
        cut("angus-eye", "beef", "Angus beef eye fillet", "Breed", "steak", listOf("angus eye fillet", "angus tenderloin")),
        cut("angus-mince", "beef", "Angus beef mince", "Breed", "mince", listOf("angus mince")),
        cut("angus-brisket", "beef", "Angus beef brisket", "Breed", "slow", listOf("angus brisket")),
        cut("angus-oyster", "beef", "Angus beef oyster blade", "Breed", "steak", listOf("angus flat iron")),
        cut("angus-sirloin", "beef", "Angus beef sirloin steaks", "Breed", "steak", listOf("angus porterhouse")),
        cut("wagyu-rump", "beef", "Wagyu beef rump steaks", "Breed", "steak", listOf("wagyu rump", "wagu rump")),
        cut("wagyu-scotch", "beef", "Wagyu beef scotch fillet", "Breed", "steak", listOf("wagyu scotch", "wagyu rib eye")),
        cut("wagyu-eye", "beef", "Wagyu beef eye fillet", "Breed", "steak", listOf("wagyu eye fillet", "wagu eye")),
        cut("wagyu-mince", "beef", "Wagyu beef mince", "Breed", "mince", listOf("wagyu mince", "wagu mince")),
        cut("wagyu-brisket", "beef", "Wagyu beef brisket", "Breed", "slow", listOf("wagyu brisket")),
        cut("wagyu-oyster", "beef", "Wagyu beef oyster blade", "Breed", "steak", listOf("wagyu flat iron")),
        cut("wagyu-stir", "beef", "Wagyu beef stir-fry strips", "Breed", "slice", listOf("wagyu strips")),
        cut("beef-brisket", "beef", "Beef brisket", "Less common", "slow"),
        cut("beef-osso", "beef", "Beef osso buco", "Less common", "slow"),
        cut("beef-cheek", "beef", "Beef cheek", "Less common", "slow"),
        cut("beef-oxtail", "beef", "Oxtail", "Less common", "slow"),
        cut("beef-short-rib", "beef", "Beef short ribs", "Less common", "slow"),
        cut("beef-skirt", "beef", "Beef skirt steak", "Less common", "steak"),
        cut("beef-flank", "beef", "Beef flank steak", "Less common", "steak", listOf("flank steak")),
        cut("beef-hanger", "beef", "Beef hanger steak", "Less common", "steak", listOf("hanging tender")),
        cut("beef-tritip", "beef", "Beef tri-tip", "Less common", "steak", listOf("tri tip")),
        cut("beef-tongue", "beef", "Beef tongue", "Less common", "offal", listOf("ox tongue")),
        cut("beef-liver", "beef", "Beef liver", "Less common", "offal"),
        cut("lamb-leg", "lamb", "Lamb leg steaks", "Everyday", "steak"),
        cut("lamb-shoulder", "lamb", "Boneless lamb shoulder", "Everyday", "slow"),
        cut("lamb-cutlet", "lamb", "Lamb cutlets", "Everyday", "bone-in"),
        cut("lamb-backstrap", "lamb", "Lamb backstrap", "Everyday", "steak", listOf("backstrap")),
        cut("lamb-loin", "lamb", "Lamb loin chops", "Everyday", "bone-in", listOf("loin chop")),
        cut("lamb-dice", "lamb", "Diced lamb", "Everyday", "slow", listOf("lamb cubes")),
        cut("lamb-mince", "lamb", "Lamb mince", "Everyday", "mince"),
        cut("lamb-shank", "lamb", "Lamb shanks", "Less common", "slow"),
        cut("lamb-neck", "lamb", "Lamb neck", "Less common", "slow"),
        cut("lamb-rump", "lamb", "Lamb rump", "Less common", "steak"),
        cut("lamb-breast", "lamb", "Lamb breast", "Less common", "slow"),
        cut("lamb-rack", "lamb", "Lamb rack", "Less common", "bone-in", listOf("rack of lamb")),
        cut("lamb-liver", "lamb", "Lamb liver", "Less common", "offal"),
        cut("lamb-sausage", "lamb", "Lamb sausages", "Less common", "slice", listOf("lamb sausage")),
        cut("pork-loin", "pork", "Boneless pork loin steaks", "Everyday", "steak"),
        cut("pork-shoulder", "pork", "Pork shoulder", "Everyday", "slow"),
        cut("pork-scotch", "pork", "Pork scotch fillet", "Everyday", "steak"),
        cut("pork-belly", "pork", "Pork belly", "Everyday", "slice"),
        cut("pork-mince", "pork", "Pork mince", "Everyday", "mince"),
        cut("pork-fillet", "pork", "Pork fillet", "Everyday", "steak", listOf("pork tenderloin", "pork medallions")),
        cut("pork-dice", "pork", "Diced pork", "Everyday", "slow", listOf("pork cubes")),
        cut("pork-sausage", "pork", "Pork sausages", "Everyday", "slice", listOf("pork sausage")),
        cut("pork-cutlet", "pork", "Pork cutlets", "Less common", "bone-in"),
        cut("pork-hock", "pork", "Pork hock", "Less common", "slow"),
        cut("pork-cheek", "pork", "Pork cheek", "Less common", "slow"),
        cut("pork-ribs", "pork", "Pork spare ribs", "Less common", "slow"),
        cut("pork-neck", "pork", "Pork neck", "Less common", "slow"),
        cut("pork-leg", "pork", "Pork leg roast", "Less common", "slow", listOf("pork leg")),
        cut("pork-trotter", "pork", "Pork trotters", "Less common", "slow", listOf("pig trotter"))
    )

    fun byId(id: String): MeatCut? = all.find { it.id == id }

    fun forMain(mainId: String, methodId: String? = null): List<MeatCut> {
        val cuts = all.filter { it.mainId == mainId }
        if (methodId.isNullOrBlank()) return cuts
        return cuts.filter { CutMethodAffinity.allowed(it, methodId) }
    }

    fun mainOf(text: String): String? {
        val folded = text.lowercase(Locale.US)
        return listOf("chicken", "turkey", "beef", "lamb", "pork").firstOrNull { folded.contains(it) }
    }

    fun searchPhrases(query: String): List<String> = ProductMatcher.searchPhrases(query)

    private fun cut(
        id: String,
        mainId: String,
        shoppingName: String,
        group: String,
        form: String,
        aliases: List<String> = emptyList()
    ) = MeatCut(id, mainId, shoppingName, group, form, aliases)
}

/**
 * Cut × method affinity for shopping prep hints (mirrors fusion-table lib/cut-method.ts).
 * Brisket + burgers → grind; brisket + braise → pull; never “cut steaks 2 cm” on a slow cut.
 */
object CutMethodAffinity {
    private val steakQuick = setOf("schnitzel", "pan-fried", "air-fried", "grilled")
    private val formMethods = mapOf(
        "fillet" to listOf("schnitzel", "baked", "pan-fried", "air-fried", "poached", "grilled", "smoked", "stir-fried", "braised", "curry", "roasted", "steamed"),
        "steak" to listOf("schnitzel", "baked", "pan-fried", "air-fried", "grilled", "stir-fried", "braised", "curry", "roasted"),
        "mince" to listOf("patties", "baked", "pan-fried", "air-fried", "grilled", "stir-fried", "braised", "curry", "roasted"),
        "bone-in" to listOf("baked", "pan-fried", "air-fried", "grilled", "smoked", "braised", "curry", "roasted", "steamed", "poached"),
        "whole" to listOf("baked", "roasted", "smoked", "braised", "curry", "steamed", "poached"),
        "offal" to listOf("pan-fried", "air-fried", "grilled", "braised", "curry", "baked", "roasted"),
        "slow" to listOf("braised", "curry", "patties", "roasted", "baked", "smoked", "stir-fried"),
        "slice" to listOf("pan-fried", "air-fried", "grilled", "smoked", "stir-fried", "baked", "roasted", "braised", "curry")
    )
    private val pullIds = setOf(
        "beef-brisket", "angus-brisket", "wagyu-brisket", "beef-cheek",
        "pork-shoulder", "pork-cheek", "pork-neck", "pork-leg",
        "lamb-shoulder", "lamb-breast", "lamb-neck", "chicken-frame"
    )
    private val smokeStaples = setOf(
        "beef-brisket", "angus-brisket", "wagyu-brisket", "beef-short-rib", "beef-chuck",
        "pork-ribs", "pork-belly", "pork-shoulder", "pork-hock", "pork-neck", "pork-leg",
        "lamb-shoulder", "lamb-breast", "lamb-shank",
        "chicken-thigh-bone", "chicken-drumstick", "chicken-wing", "chicken-wingette",
        "chicken-maryland", "chicken-whole", "chicken-spatchcock", "chicken-thigh-fillet",
        "turkey-breast", "turkey-thigh", "turkey-whole"
    )
    private val sausageIds = setOf("beef-sausage", "lamb-sausage", "pork-sausage")

    fun allowed(cut: MeatCut, methodId: String): Boolean {
        val methods = formMethods[cut.form] ?: return false
        if (methodId !in methods) return false
        if (methodId == "smoked") {
            if (cut.form == "mince" || cut.form == "offal" || cut.form == "steak") return false
            return cut.id in smokeStaples
        }
        if (methodId == "schnitzel" && cut.form in setOf("bone-in", "whole", "slow", "mince")) return false
        if (methodId == "schnitzel" && cut.id in sausageIds) return false
        if (methodId == "stir-fried" && cut.form == "whole") return false
        if (methodId == "poached" && (cut.form == "mince" || cut.form == "slow" || cut.id in sausageIds)) return false
        return true
    }

    /** Infer a cooking method keyword from a shopping line title when the planner does not send one. */
    fun inferMethod(lineName: String): String? {
        val t = lineName.lowercase(Locale.US)
        return when {
            "schnitzel" in t || "parma" in t -> "schnitzel"
            "burger" in t || "patty" in t || "pattie" in t || "meatball" in t -> "patties"
            "smok" in t -> "smoked"
            "stir" in t -> "stir-fried"
            "brais" in t || "stew" in t || "casserole" in t || "pulled" in t -> "braised"
            "curry" in t -> "curry"
            "grill" in t || "bbq" in t || "barbecue" in t -> "grilled"
            "roast" in t -> "roasted"
            "bake" in t -> "baked"
            else -> null
        }
    }

    fun prepHint(cut: MeatCut, methodId: String?): String {
        val method = methodId ?: return suitsSummary(cut)
        if (!allowed(cut, method)) {
            return when {
                method == "smoked" && cut.form == "mince" ->
                    "Mince is not hot-smoked. Choose patties, or brisket/ribs for the smoker."
                method == "smoked" ->
                    "Not a usual hot-smoke cut. Try brisket, ribs, belly or shoulder."
                cut.form == "slow" && method in steakQuick ->
                    "Slow cut — not for ${method.replace('-', ' ')} as steaks. Braise, smoke, curry, or grind for patties."
                cut.form == "whole" -> "Whole bird — roast, bake, smoke or braise; not schnitzel or patties."
                cut.form == "mince" && method == "schnitzel" -> "Mince suits patties, not crumbed steaks."
                else -> "This cut does not suit ${method.replace('-', ' ')}. Pick another cut or method."
            }
        }
        return when {
            method == "smoked" ->
                "Hot-smoke as a joint: bark, stall if needed, rest, then slice or pull — not mince or patties."
            cut.form == "slow" && method == "patties" ->
                "Grind this ${cut.shoppingName.lowercase(Locale.US)} for patties — do not cut steaks."
            cut.form == "slow" && method in setOf("braised", "curry") && cut.id in pullIds ->
                "Cook in large pieces until tender, then shred or pull. Do not cut into steaks."
            cut.form == "slow" && method in setOf("braised", "curry") ->
                "Cut into even cubes for simmering — not steaks."
            cut.form == "mince" ->
                "Keep mince chilled. Shape patties or cook crumbled — not steak slices."
            cut.id in sausageIds ->
                "Cook as links, not steaks."
            cut.form == "steak" || cut.form == "fillet" ->
                if (method == "schnitzel") "Flatten to an even thin piece for crumbed cooking."
                else if (method == "grilled" || method == "pan-fried") "Portion to an even thickness; pat dry."
                else suitsSummary(cut)
            else -> suitsSummary(cut)
        }
    }

    private fun suitsSummary(cut: MeatCut): String {
        val methods = formMethods[cut.form].orEmpty().take(4).joinToString(", ") { it.replace('-', ' ') }
        return "Suits: $methods. Check the packet."
    }
}

data class CatalogueProduct(
    val name: String,
    val priceCents: Long?,
    val packageSize: String?,
    val inStock: Boolean?,
    val available: Boolean?,
    val url: String?
)

data class ProductMatch(
    val name: String,
    val priceCents: Long?,
    val packageSize: String?,
    val stock: String,
    val url: String?,
    val score: Int,
    val selected: Boolean,
    val reason: String
)

data class ParsedCatalogue(
    val products: List<CatalogueProduct>,
    val fulfilmentStoreId: String?
)

object CatalogueMoney {
    fun audToCents(value: Double): Long? {
        if (!value.isFinite() || value <= 0.0) return null
        return centsFromDecimal(String.format(Locale.US, "%.3f", value))
    }

    fun audToCents(text: String): Long? {
        val cleaned = text.trim().removePrefix("A$").removePrefix("a$").removePrefix("$").replace(",", "")
        if (!Regex("""^\d+(\.\d+)?$""").matches(cleaned)) return null
        if ((cleaned.toDoubleOrNull() ?: 0.0) <= 0.0) return null
        val parts = cleaned.split(".")
        val fraction = (parts.getOrElse(1) { "" } + "000").take(3)
        return centsFromDecimal("${parts[0]}.$fraction")
    }

    fun formatAudCents(cents: Long?): String? {
        if (cents == null || cents <= 0L) return null
        return "A$%d.%02d".format(cents / 100, cents % 100)
    }

    /** Sum of selected positive prices. No selection is null, never zero. */
    fun subtotal(cents: List<Long?>): Long? {
        val priced = cents.mapNotNull { it }.filter { it > 0L }
        return if (priced.isEmpty()) null else priced.sum()
    }

    private fun centsFromDecimal(fixed3: String): Long? {
        val parts = fixed3.split(".")
        if (parts.size != 2 || parts[1].length != 3) return null
        val dollars = parts[0].toLongOrNull() ?: return null
        if (dollars > 100_000) return null
        var cents = dollars * 100 + parts[1].take(2).toLong()
        if (parts[1][2].digitToInt() >= 5) cents += 1
        return if (cents > 0) cents else null
    }
}

object ProductMatcher {
    private val stop = setOf(
        "woolworths", "coles", "aldi", "rspca", "approved", "fresh", "australian", "the", "and", "with",
        "per", "kg", "each", "approx", "selected", "product", "free", "range", "macro"
    )
    private val whiteFish = setOf("cod", "hoki", "barramundi", "haddock", "pollock", "hake", "basa")
    private val finFish = whiteFish + setOf("salmon", "tuna", "sardine", "trout", "snapper", "tilapia", "anchovy")
    private val plantProteins = setOf("tofu", "tempeh", "halloumi", "paneer", "chickpea", "lentil", "bean", "jackfruit")
    private val proteins = listOf(
        "chicken", "turkey", "beef", "lamb", "pork", "duck", "kangaroo", "veal", "goat", "venison", "quail", "goose",
        "fish", "prawn", "crab", "lobster", "squid", "calamari", "octopus", "scallop", "mussel", "oyster",
        "egg"
    ) + plantProteins + finFish
    private val phrases = listOf(
        "eye-fillet" to "eye fillet",
        "poultry-tender" to "poultry tender",
        "oyster-blade" to "oyster blade",
        "short-rib" to "short rib",
        "spare-rib" to "spare rib",
        "osso-buco" to "osso buco",
        "gravy-beef" to "gravy beef",
        "gravy-beef" to "beef shin",
        "scotch" to "scotch fillet",
        "scotch" to "scotch",
        "sirloin" to "sirloin",
        "maryland" to "maryland",
        "drumstick" to "drumstick",
        "spatchcock" to "spatchcock",
        "oxtail" to "oxtail",
        "brisket" to "brisket",
        "mince" to "mince",
        "breast" to "breast",
        "thigh" to "thigh",
        "wing" to "wing",
        "rump" to "rump",
        "chuck" to "chuck",
        "cheek" to "cheek",
        "liver" to "liver",
        "cutlet" to "cutlet",
        "shank" to "shank",
        "hock" to "hock",
        "belly" to "belly",
        "neck" to "neck",
        "loin" to "loin",
        "shoulder" to "shoulder",
        "leg" to "leg",
        "skirt" to "skirt",
        "whole" to "whole chicken",
        "whole" to "whole turkey",
        "whole" to "whole bird",
        "bolar" to "bolar blade",
        "bolar" to "bolar",
        "silverside" to "silverside",
        "topside" to "topside",
        "t-bone" to "t bone",
        "flank" to "flank",
        "hanger" to "hanger",
        "tri-tip" to "tri tip",
        "backstrap" to "backstrap",
        "rack" to "lamb rack",
        "diced" to "diced",
        "sausage" to "sausage",
        "tongue" to "tongue",
        "trotter" to "trotter",
        "frame" to "chicken frame",
        "frame" to "chicken carcass",
        "heart" to "chicken heart",
        "gizzard" to "gizzard",
        "strips" to "stir fry",
        "pork-fillet" to "pork fillet",
        "wingette" to "wingette",
        "wingette" to "drumette",
        "wingette" to "wing nibble"
    )

    // Match only food listings. Seed names by themselves remain edible; explicit
    // planting instructions or the observed horticultural seed brand are needed.
    private val nonFoodNames = listOf(
        Regex("""\b(diffuser|diffusers|aroma oil|essential oil|fragrance oil|scented candles?)\b"""),
        Regex("""\b(hair|body|face|facial|hand) (oil|cream|lotion|butter|treatment|shampoo|conditioner)\b|\b(oil|cream|serum) for (hair|body|face|skin)\b"""),
        Regex("""\b(seedlings?|seed tapes?|seed mats?|seed raising kits?|grow kits?|growing kits?|planting seeds?|sowing seeds?|seeds? for (planting|sowing|growing))\b"""),
        Regex("""\b(compost|potting mix|fertiliser|fertilizer|pesticide|fungicide|insecticide|plant food|mushroom spawn|garden hoses?|garden stakes?|chicken wire|wire mesh)\b"""),
        Regex("""\b(juicers?|squeezers?|slicers?|dicers?|spirali[sz]ers?|mandolines?|cutter gadgets?|vegetable cutters?|vegetable choppers?|food choppers?|citrus press|lemon press|garlic press|garlic crusher|tofu press|vegetable peeler|potato peeler|cheese grater|zester|knife sharpener|knife block|chopping board|cutting board|kitchen utensil|measuring cups?|measuring spoons?|baking trays?|baking tins?|muffin trays?|muffin tins?|food processor)\b"""),
        Regex("""\b(taco|tortilla|burrito|egg|toast|rib) (holders?|stands?|racks?|warmers?)\b|\b(holders?|stands?|racks?) for (soft or hard )?(tacos?|tortillas?|burritos?)\b|\b(stainless steel|steel|metal|silicone|ceramic|plastic)\b.{0,70}\b(holders?|racks?|baking trays?|serving trays?|moulds?|molds?|tongs?|spatulas?)\b"""),
        Regex("""\b(dogs?|pupp(y|ies)|cats?|kittens?|pets?)\b.{0,64}\b(leads?|leashes?|collars?|harness(es)?|toys?|beds?|bowls?|treats?|food|kibble|litter|shampoo|grooming)\b"""),
        Regex("""\b(food|treats?|kibble) for (dogs?|puppies|cats?|kittens?|pets?)\b"""),
        Regex("""\b(dishwashing liquid|dishwasher (tablets?|capsules?|detergent)|laundry detergent|cleaning spray|surface cleaner|hand wash|body wash)\b""")
    )

    private fun isNonFoodName(raw: String): Boolean {
        val name = raw.take(500).lowercase(Locale.US).replace(Regex("""[^a-z0-9]+"""), " ")
        return nonFoodNames.any { it.containsMatchIn(name) } ||
            Regex("""\bseeds?\b""").containsMatchIn(name) && Regex("""\byates\b""").containsMatchIn(name)
    }

    // These checks establish food identity, not packet/allergen certification.
    // A shared flavour or cut word cannot turn another food into this ingredient.
    private val foodAnchors = setOf(
        "onion", "garlic", "ginger", "carrot", "broccoli", "cauliflower", "cabbage", "capsicum", "courgette", "eggplant", "cucumber",
        "spinach", "lettuce", "lemon", "lime", "orange", "apple", "banana", "pear", "mushroom", "coriander", "parsley", "basil", "mint",
        "potato", "tomato", "pumpkin", "celery", "fennel", "rice", "tofu", "flour", "pasta", "noodle", "miso", "vinegar", "oil",
        "sugar", "honey", "stock", "egg", "bean", "lentil", "chickpea", "oat", "quinoa", "couscous", "bread", "tortilla",
        "tempeh", "halloumi", "paneer", "jackfruit"
    )
    private val animalFood = Regex("""\b(chicken|turkey|beef|lamb|pork|duck|goat|venison|kangaroo|veal|fish|salmon|tuna|trout|cod|barramundi|hake|basa|prawn|shrimp|crab|lobster|squid|calamari|octopus|scallop|mussel|oyster|ham|bacon|salami|prosciutto|pancetta|chorizo|pastrami|mortadella|pepperoni|egg)\b""")
    private val plantMeat = Regex("""\b(plant based|plantbased|plant protein|vegan|vegetarian|meat free|meatfree|meatless|non meat)\b""")
    private val plantDairy = Regex("""\b(plant based|plantbased|vegan|dairy free|dairyfree|non dairy|plant (milk|cream|butter|cheese|yogurt))\b""")
    private val plantBases = setOf("coconut", "soy", "oat", "almond", "cashew", "macadamia", "rice", "pea", "hemp", "hazelnut", "walnut", "peanut", "sesame", "sunflower", "pistachio", "cocoa", "cacao")
    private val cheeseName = Regex("""\b(cheese|mozzarella|cheddar|parmesan|feta|halloumi|ricotta|mascarpone|paneer|provolone|pecorino|gruyere|bocconcini|brie|camembert|gouda|edam)\b""")
    private data class DairyIdentity(val kind: String, val plant: Boolean, val bases: Set<String>)

    private fun identityText(value: String): String = value
        .replace(Regex("""\b(scallion|green onion)\b"""), "spring onion")
        .replace(Regex("""\bsoya\b"""), "soy")
        .replace(Regex("""\bbean curd\b"""), "tofu")

    private fun dairyIdentity(value: String): DairyIdentity? {
        if (Regex("""\b(butter bean|butterbean)\b""").containsMatchIn(value)) return DairyIdentity("butter-bean", true, emptySet())
        if (Regex("""\bcream of tartar\b""").containsMatchIn(value)) return DairyIdentity("cream-of-tartar", true, emptySet())
        val kind = when {
            Regex("""\byogurt\b""").containsMatchIn(value) -> "yogurt"
            cheeseName.containsMatchIn(value) -> "cheese"
            Regex("""\bbutter\b""").containsMatchIn(value) -> "butter"
            Regex("""\bbuttermilk\b""").containsMatchIn(value) -> "buttermilk"
            Regex("""\bmilk\b""").containsMatchIn(value) -> "milk"
            Regex("""\bcream\b""").containsMatchIn(value) -> "cream"
            else -> return null
        }
        val bases = value.split(" ").filter { it in plantBases }.toSet()
        return DairyIdentity(kind, bases.isNotEmpty() || plantDairy.containsMatchIn(value), bases)
    }

    private fun ingredientIdentityConflict(wanted: String, seen: String): Boolean {
        val request = identityText(wanted)
        val product = identityText(seen)
        val offeredWords = product.split(" ").toSet()
        if (request.split(" ").any { it in foodAnchors && it !in offeredWords }) return true
        if (proteinIdentityConflict(request, product)) return true
        // Sweet potato is another ingredient, not a named potato variety.
        if (Regex("""\bpotato\b""").containsMatchIn(request) && Regex("""\bpotato\b""").containsMatchIn(product) &&
            Regex("""\bsweet\b""").containsMatchIn(request) != Regex("""\bsweet\b""").containsMatchIn(product)) return true
        if (Regex("""\b(chicken|turkey)\b""").containsMatchIn(request) && Regex("""\bbreast\b""").containsMatchIn(request) &&
            Regex("""\bfillet\b""").containsMatchIn(request) && Regex("""\b(buffe|buffet|crown)\b""").containsMatchIn(product) &&
            !Regex("""\b(buffe|buffet|crown)\b""").containsMatchIn(request)) return true
        if ((animalFood.containsMatchIn(request) || animalFood.containsMatchIn(product)) &&
            plantMeat.containsMatchIn(request) != plantMeat.containsMatchIn(product)) return true
        if (Regex("""\bmince\b""").containsMatchIn(request)) {
            if (plantMeat.containsMatchIn(request) && !plantMeat.containsMatchIn(product)) return true
            if (Regex("""\bvegan\b""").containsMatchIn(request) && !Regex("""\bvegan\b""").containsMatchIn(product)) return true
            if (!plantMeat.containsMatchIn(request)) {
                val requestedAnimals = proteinsOf(request) - "tofu"
                val offeredAnimals = proteinsOf(product) + if (breedOf(product) != "ordinary") setOf("beef") else emptySet()
                // A shared generic mince form cannot prove that an unnamed food
                // contains beef/chicken/etc. No dietary proof is inferred from brands.
                if (requestedAnimals.any { it !in offeredAnimals }) return true
            }
        }
        val left = dairyIdentity(request) ?: return false
        val right = dairyIdentity(product) ?: return false
        if (left.kind != right.kind || left.plant != right.plant) return true
        if (left.kind == "butter") {
            // Keep explicitly requested compound butters, without pricing them
            // as plain cooking butter or dropping their named flavour.
            for (flavour in listOf("garlic", "herb")) {
                val marker = Regex("""\b$flavour\b""")
                if (marker.containsMatchIn(request) != marker.containsMatchIn(product)) return true
            }
        }
        if (left.plant) {
            // Generic vegan cooking butter is not a named nut/seed butter.
            if (left.kind == "butter" && left.bases.isEmpty() != right.bases.isEmpty()) return true
            if (left.bases.isNotEmpty() && left.bases != right.bases) return true
        }
        return false
    }

    private val produceWords = setOf("ginger", "garlic", "onion", "scallion", "shallot", "leek", "tomato", "potato", "carrot", "beetroot", "broccoli", "cauliflower", "cabbage", "capsicum", "courgette", "eggplant", "cucumber", "spinach", "lettuce", "lemon", "lime", "orange", "apple", "banana", "pear", "mushroom", "coriander", "parsley", "basil", "mint", "dill", "rosemary", "thyme", "sage", "chilli", "celery", "fennel", "asparagus")
    private val finishedFoodForms = listOf(
        "biscuit" to Regex("""\b(biscuit|cookie|biscotti)\b"""),
        "cake" to Regex("""\b(cake|muffin|pastry|doughnut|donut|waffle|pancake)\b"""),
        "bread" to Regex("""\b(bread|crispbread|gingerbread|shortbread|naan|flatbread|bagel|baguette|bun|crouton|breadstick|wrap|tortilla)\b"""),
        "cracker" to Regex("""\bcracker\b"""), "snack" to Regex("""\b(chip|crisp|crispy|snack|popcorn)\b"""),
        "chutney" to Regex("""\bchutney\b"""), "relish" to Regex("""\brelish\b"""), "pesto" to Regex("""\bpesto\b"""),
        "ketchup" to Regex("""\bketchup\b"""), "jelly" to Regex("""\bjelly\b"""), "jam" to Regex("""\b(jam|marmalade|conserve)\b"""),
        "chocolate" to Regex("""\b(chocolate|fudge|candy|confectionery)\b"""), "dressing" to Regex("""\bdressing\b"""),
        "dip" to Regex("""\b(dip|hummus|houmous|guacamole)\b"""), "mayonnaise" to Regex("""\b(mayonnaise|mayo|aioli)\b"""),
        "cordial" to Regex("""\bcordial\b"""), "beer" to Regex("""\b(beer|ale|cider)\b"""), "syrup" to Regex("""\bsyrup\b"""),
        "pasta" to Regex("""\b(pasta|lasagne|lasagna|noodle)\b"""), "pizza" to Regex("""\bpizza\b"""),
        "salt" to Regex("""\bsalt\b"""), "butter" to Regex("""\bbutter\b"""), "curd" to Regex("""\bcurd\b"""),
        "risotto" to Regex("""\brisotto\b"""), "bake" to Regex("""\b(bake|gratin)\b"""), "passata" to Regex("""\bpassata\b""")
    )
    private val producePreparations = listOf(
        Regex("""\b(jarred|bottled|canned|tinned|preserved)\b"""), Regex("""\bpickled\b"""),
        Regex("""\b(candied|crystallised|crystalized)\b"""), Regex("""\b(ground|dried|dehydrated)\b"""),
        Regex("""\b(cooked|roast|roasted|grilled|baked|fried|steamed|caramelised|caramelized)\b"""),
        Regex("""\b(frozen|quicksteam|quick steam|steam fresh|ready to steam|microwave)\b"""), Regex("""\bready cut\b""")
    )

    private fun otherFoodPreparationConflict(wanted: String, seen: String): Boolean {
        val produceRequest = wanted.split(" ").any { it in produceWords } || Regex("""\b(corn|pumpkin|butternut|okra|kale|avocado|green bean|snow pea|sugar snap pea)\b""").containsMatchIn(wanted)
        val forms = finishedFoodForms.filter { produceRequest || it.first !in setOf("salt", "butter", "curd", "risotto", "bake") }
        val requested = forms.filter { it.second.containsMatchIn(wanted) }
        if (requested.isNotEmpty()) {
            // Garlic butter bread is still explicitly requested garlic bread;
            // butter within that food is not a different primary food form.
            return requested.any { !it.second.containsMatchIn(seen) }
        }
        if (forms.any { it.second.containsMatchIn(seen) }) return true
        if (!produceRequest || cookingFoodForms(wanted).isNotEmpty() || Regex("""\b(seed|flake|stem ginger)\b""").containsMatchIn(wanted)) return false
        if (producePreparations.any { it.containsMatchIn(seen) != it.containsMatchIn(wanted) }) return true
        if (!Regex("""\b(mixed|mix|medley|vegetable|veggie|salad)\b""").containsMatchIn(wanted)) {
            fun produceNames(value: String) = value.replace(Regex("""\bsweet potato\b"""), "sweetpotato")
                .replace(Regex("""\bbutternut( squash)?\b"""), "pumpkin").split(" ")
                .filter { it in produceWords || it in setOf("sweetpotato", "corn", "pea", "bean", "pumpkin", "okra", "kale", "avocado") }.toSet()
            val requestedProduce = produceNames(wanted)
            if (requestedProduce.size == 1 && produceNames(seen).any { it !in requestedProduce }) return true
            if (requestedProduce.size == 1 && Regex("""\b(mixed vegetables?|vegetable mix|vegetable medley|mixed veggies|roast veggies|roast vegetables)\b""").containsMatchIn(seen)) return true
        }
        if (Regex("""\b(ginger|garlic)\b""").containsMatchIn(wanted)) {
            for (preparation in listOf(Regex("""\bcrushed\b"""), Regex("""\bchopped\b"""))) {
                if (preparation.containsMatchIn(seen) && !preparation.containsMatchIn(wanted) &&
                    !Regex("""\b(fresh|root|punnet|loose|bulb|clove)\b""").containsMatchIn(seen)) return true
            }
        }
        return false
    }

    private fun freshHerbPackUnverified(wanted: String, product: CatalogueProduct): Boolean {
        if (!Regex("""\b(coriander|parsley|basil|mint|dill|rosemary|thyme|sage|oregano|tarragon|chive|chervil)\b""").containsMatchIn(wanted) ||
            Regex("""\b(dried|dry|ground|powder|seed|paste|sauce|oil|tea|infusion|flake|frozen|preserved|pickled|tinned|canned|jarred)\b""").containsMatchIn(wanted)) return false
        val seen = canonicalize(product.name)
        if (Regex("""\b(fresh|bunch|punnet|potted|pot|living|hydroponic|microherb|microgreen)\b""").containsMatchIn(seen)) return false
        val pack = product.packageSize.orEmpty().trim().lowercase(Locale.US).replace(Regex("""\s+"""), " ")
        val size = Regex("""^(?:(\d{1,3})\s*x\s*)?(\d+(?:\.\d+)?)\s*(kg|g)(?:\s*x\s*(\d{1,3}))?$""").matchEntire(pack) ?: return false
        if (size.groupValues[1].isNotEmpty() && size.groupValues[4].isNotEmpty()) return false
        val grams = size.groupValues[2].toDouble() * (if (size.groupValues[3] == "kg") 1000 else 1) *
            (size.groupValues[1].toDoubleOrNull() ?: size.groupValues[4].toDoubleOrNull() ?: 1.0)
        // This is uncertainty about food form, not proof that a tiny pack is dried.
        return grams.isFinite() && grams > 0 && grams <= 10
    }

    private fun cookingFoodForms(value: String): Set<String> = buildSet {
        if (Regex("""\b(stock|broth|bouillon)\b""").containsMatchIn(value)) add("stock")
        if (Regex("""\bgravy\b""").containsMatchIn(value) && !Regex("""\bgravy beef\b""").containsMatchIn(value)) add("gravy")
        for (form in listOf("paste", "sauce", "soup", "juice", "powder")) if (Regex("""\b${form}(ed)?\b""").containsMatchIn(value)) add(form)
    }

    private fun meatPreparations(value: String, product: Boolean = false): MutableSet<String> {
        val forms = mutableSetOf<String>()
        if (Regex("""\b(cooked|precooked|pre cooked|ready to eat|rotisserie|grilled|chargrilled|char grilled|roasted|baked|poached|steamed|boiled|sous vide|barbecued|fried|pulled)\b""").containsMatchIn(value)) forms += "cooked"
        if (Regex("""\bsmoked\b""").containsMatchIn(value)) forms += "smoked"
        if (Regex("""\b(crumbed|crumb|breaded|battered|schnitzel|tempura|nugget|chipee|munchie|kiev|kyiv|cordon bleu)\b""").containsMatchIn(value)) forms += "breaded"
        if (Regex("""\b(marinated|marinade|seasoned|flavoured|flavored|self basting|self basted|injected|honey soy|teriyaki|satay)\b""").containsMatchIn(value)) forms += "marinated"
        if (Regex("""\b(deli|sandwich|luncheon|cold cut)\b""").containsMatchIn(value)) forms += "deli"
        if (Regex("""\b(ham|bacon|salami|prosciutto|pancetta|chorizo|pastrami|mortadella|pepperoni|cured|corned)\b""").containsMatchIn(value)) forms += "cured"
        val poultry = Regex("""\b(chicken|turkey)\b""").containsMatchIn(value)
        // Whole poultry names describe a cut, not proof that a roast is raw.
        val explicitRaw = Regex("""\b(raw|uncooked|for cooking|for roasting|roasting joint|roast joint|roast cut)\b""").containsMatchIn(value)
        if (poultry && !explicitRaw && Regex("""\b(carved|shredded|roast)\b""").containsMatchIn(value)) forms += "cooked"
        if (poultry && !explicitRaw && Regex("""\b(thinly sliced|sliced|slice|shaved|carved|shredded)\b""").containsMatchIn(value) &&
            (product || "cooked" in forms || "deli" in forms)) {
            forms += "deli"
            forms += "cooked"
        }
        return forms
    }

    private fun ingredientPreparationConflict(wanted: String, seen: String): Boolean {
        val requestedFood = cookingFoodForms(wanted)
        val offeredFood = cookingFoodForms(seen)
        if (requestedFood != offeredFood) return true
        if (!animalFood.containsMatchIn(wanted) && !animalFood.containsMatchIn(seen)) return false
        if (requestedFood.isNotEmpty()) return false // Roast chicken stock is still stock, not raw poultry.
        val requested = meatPreparations(wanted)
        val offered = meatPreparations(seen, product = true)
        if (listOf("smoked", "cured", "deli").any { it in requested && it in offered }) {
            requested -= "cooked"
            offered -= "cooked"
            if ("deli" !in requested) offered -= "deli"
        }
        if ("cooked" in requested && "cooked" in offered && "deli" !in requested) offered -= "deli"
        return requested != offered
    }

    fun match(query: String, products: List<CatalogueProduct>, limit: Int = 6): List<ProductMatch> {
        val wanted = canonicalize(query)
        if (wanted.length < 2) return emptyList()
        val wantedTokens = tokensOf(wanted)
        val wantedCuts = familiesOf(wanted)
        val wantedProteins = proteinsOf(wanted)
        val wantedBreed = breedOf(wanted)
        val wantedBone = boneStyle(wanted)
        val ranked = mutableListOf<ProductMatch>()
        for (product in products) {
            if (product.name.isBlank() || isNonFoodName(product.name) || freshHerbPackUnverified(wanted, product)) continue
            val seen = canonicalize(product.name)
            if (ingredientIdentityConflict(wanted, seen) || ingredientPreparationConflict(wanted, seen) || otherFoodPreparationConflict(wanted, seen)) continue
            if (Regex("""\bsausage roll\b""").containsMatchIn(seen) && !Regex("""\bsausage roll\b""").containsMatchIn(wanted)) continue
            if (Regex("""\bsauce\b""").containsMatchIn(seen) && !Regex("""\bsauce\b""").containsMatchIn(wanted)) continue
            val seenTokens = tokensOf(seen).toSet()
            val seenCuts = familiesOf(seen)
            val seenProteins = proteinsOf(seen)
            val sharedProtein = wantedProteins.isNotEmpty() && seenProteins.isNotEmpty()
            if (cutsConflict(wantedCuts, seenCuts)) continue
            val seenBreed = breedOf(seen)
            if (wantedBreed != "ordinary" && wantedBreed != seenBreed) continue
            val overlap = wantedTokens.count { it in seenTokens }
            val sharedCut = wantedCuts.any { it in seenCuts }
            if (overlap == 0 && !sharedCut && !sharedProtein) continue
            var score = overlap * 10
            if (wantedTokens.isNotEmpty() && overlap == wantedTokens.size) score += 15
            if (sharedProtein) score += if (overlap == 0) 40 else 25
            if (sharedCut) score += 30
            if (wantedBreed != "ordinary" && wantedBreed == seenBreed) score += 15
            if (wantedBreed == "ordinary" && seenBreed == "ordinary") score += 5
            val stock = stockFlag(product.inStock, product.available)
            val premium = wantedBreed == "ordinary" && seenBreed != "ordinary"
            val boneMismatch = wantedBone != null && boneStyle(seen) != null && wantedBone != boneStyle(seen)
            if (premium) score -= 40
            if (boneMismatch) score -= 15
            val priced = product.priceCents != null && product.priceCents > 0L
            var selected = !premium && !boneMismatch && stock == "IN_STOCK" && priced && (overlap > 0 || sharedProtein)
            if (wantedCuts.isNotEmpty() && !sharedCut) selected = false
            if (!(overlap == wantedTokens.size || sharedCut || score >= 40)) selected = false
            val reason = when {
                premium -> if (seenBreed == "wagyu") "Wagyu is another option. It was not selected for an ordinary cut." else "Angus is another option. It was not selected for an ordinary cut."
                boneMismatch -> "The bone-in and boneless names do not agree, so this was not selected."
                stock == "OUT_OF_STOCK" -> "Out of stock in the online catalogue. Not selected."
                stock == "UNKNOWN" -> "The catalogue did not say whether this is in stock. Not selected."
                !priced -> "No catalogue price. Not selected, and not counted as $0."
                selected -> "Cut and name agree. In stock in the online catalogue."
                else -> "Shown as another catalogue wording. Not the automatic pick."
            }
            ranked += ProductMatch(
                product.name.trim(),
                if (priced) product.priceCents else null,
                product.packageSize,
                stock,
                product.url,
                score,
                selected,
                reason
            )
        }
        val ordered = ranked.sortedWith(compareByDescending<ProductMatch> { it.selected }.thenByDescending { it.score }.thenBy { it.name })
        val selectable = ordered.filter { it.selected }
        val top = selectable.firstOrNull()
        val tied = top != null && selectable.any { it !== top && it.score == top.score }
        val splitCuts = wantedCuts.isEmpty() && selectable.map { familiesOf(canonicalize(it.name)).firstOrNull() ?: "" }.toSet().size > 1
        val adjusted = if (top == null || tied || splitCuts) {
            ordered.map { match ->
                if (!match.selected) match
                else match.copy(selected = false, reason = if (tied || splitCuts) "More than one catalogue row fits. Nothing was selected automatically." else match.reason)
            }
        } else {
            ordered.map { match ->
                if (match === top) match
                else if (match.selected) match.copy(selected = false, reason = "Another catalogue wording. Not the automatic pick.")
                else match
            }
        }
        return adjusted.take(limit.coerceAtLeast(1))
    }

    fun canonicalize(value: String): String {
        var text = value.lowercase(Locale.US)
            .replace(Regex("""\bwagu\b"""), "wagyu")
            .replace(Regex("""\byoghurt\b"""), "yogurt")
            .replace(Regex("""\bcilantro\b"""), "coriander")
            .replace(Regex("""\bshrimps?\b"""), "prawn")
            .replace(Regex("""\bgarbanzo(?: beans?)?\b"""), "chickpea")
            .replace(Regex("""\baubergine\b"""), "eggplant")
            .replace(Regex("""\bzucchini\b"""), "courgette")
            .replace(Regex("""\bribeye\b"""), "rib eye")
            .replace(Regex("""\bground (beef|chicken|lamb|pork|turkey)\b"""), "$1 mince")
            .replace(Regex("""[^a-z0-9]+"""), " ")
            .trim()
        text = text.split(" ").filter { it.isNotEmpty() }.joinToString(" ") { stem(it) }
        if (!Regex("""\b(black pepper|white pepper|peppercorn)\b""").containsMatchIn(text)) {
            text = text.replace(Regex("""\bbell pepper\b"""), "capsicum")
                .replace(Regex("""\b(red|green|yellow|orange) pepper\b"""), "$1 capsicum")
        }
        text = text.replace(Regex("""\bporterhouse\b"""), "sirloin")
            .replace(Regex("""\brib eye\b"""), "scotch fillet")
            .replace(Regex("""\bflat iron\b"""), "oyster blade")
            .replace(Regex("""\bdrum stick\b"""), "drumstick")
            .replace(Regex("""\box tail\b"""), "oxtail")
            .replace(Regex("""\bossobuco\b"""), "osso buco")
            .replace(Regex("""\bcube roll\b"""), "scotch fillet")
            .replace(Regex("""\bnew york steak\b"""), "sirloin")
            .replace(Regex("""\bhanging tender\b"""), "hanger")
            .replace(Regex("""\brack of lamb\b"""), "lamb rack")
            .replace(Regex("""\btbone\b"""), "t bone")
            .replace(Regex("""\btritip\b"""), "tri tip")
        text = when {
            Regex("""\b(chicken|turkey)\b""").containsMatchIn(text) -> text.replace(Regex("""\btenderloin\b"""), "poultry tender")
            Regex("""\bpork\b""").containsMatchIn(text) -> text.replace(Regex("""\btenderloin\b"""), "pork fillet").replace(Regex("""\bmedallion\b"""), "pork fillet")
            Regex("""\bbeef\b""").containsMatchIn(text) -> text.replace(Regex("""\btenderloin\b"""), "eye fillet").replace(Regex("""\bfillet steak\b"""), "eye fillet")
            else -> text
        }
        return text.replace(Regex("""\s+"""), " ").trim()
    }

    private fun stem(token: String): String {
        when (token) {
            "chillies", "chilies", "chilis", "chillie", "chili" -> return "chilli"
            "eggs" -> return "egg"
            "tomatoes" -> return "tomato"
            "potatoes" -> return "potato"
        }
        if (token.length > 5 && token.endsWith("oes")) return token.dropLast(3) + "o"
        if (token.length > 4 && token.endsWith("s") && !token.endsWith("ss") && !token.endsWith("us") && !token.endsWith("is")) {
            return token.dropLast(1)
        }
        return token
    }

    private fun tokensOf(canonical: String): List<String> =
        canonical.split(" ").filter { it.length > 1 && it !in stop && !Regex("""^\d+(g|kg|ml|l|pk|pack)?$""").matches(it) }

    private fun familiesOf(canonical: String): Set<String> {
        val padded = " $canonical "
        return phrases.filter { padded.contains(" ${it.second} ") }.map { it.first }.toSet()
    }

    private fun proteinsOf(canonical: String): Set<String> {
        // A known brand and named cuts/fungi do not identify another animal.
        val text = identityText(canonical).replace(Regex("""\bluv a duck\b"""), " ")
            .replace(Regex("""^squid (brand )?(?=.*\bfish sauce\b)"""), "")
            .replace(Regex("""\boyster (?=blade\b|mushroom\b)"""), "")
        val dairyFood = dairyIdentity(text)?.kind?.let { it != "butter-bean" } == true &&
            !Regex("""\b(meat|steak|mince|fillet|sausage|breast|thigh|drumstick|wing|chop|rib|cutlet|roast)\b""").containsMatchIn(text)
        val eggs = Regex("""\begg\b""").containsMatchIn(text)
        val found = proteins.filter { (!dairyFood && !eggs || it in plantProteins) && Regex("""\b$it\b""").containsMatchIn(text) }.toMutableSet()
        if (eggs) found += when {
            Regex("""\bduck\b""").containsMatchIn(text) -> "duck-egg"
            Regex("""\bquail\b""").containsMatchIn(text) -> "quail-egg"
            Regex("""\bgoose\b""").containsMatchIn(text) -> "goose-egg"
            else -> "egg"
        }
        if (found.any { it in finFish }) found -= "fish"
        else if (Regex("""\bwhite ?fish\b""").containsMatchIn(text)) { found -= "fish"; found += "white-fish" }
        if (breedOf(text) != "ordinary") found += "beef"
        if ("bean" in found) {
            val variety = when {
                Regex("""\b(butter|lima) bean\b""").containsMatchIn(text) -> "butter-bean"
                Regex("""\bblack (turtle )?bean\b""").containsMatchIn(text) -> "black-bean"
                Regex("""\bkidney bean\b""").containsMatchIn(text) -> "kidney-bean"
                Regex("""\bgreen bean\b""").containsMatchIn(text) -> "green-bean"
                else -> null
            }
            if (variety != null) { found -= "bean"; found += variety }
        }
        return found
    }

    private fun compatibleProtein(wanted: String, offered: String): Boolean = when (wanted) {
        "fish" -> offered == "fish" || offered == "white-fish" || offered in finFish
        "white-fish" -> offered == "white-fish" || offered in whiteFish
        "bean" -> offered == "bean" || offered in setOf("butter-bean", "black-bean", "kidney-bean", "green-bean")
        else -> wanted == offered
    }

    private fun proteinIdentityConflict(wanted: String, seen: String): Boolean {
        val left = proteinsOf(wanted)
        val right = proteinsOf(seen)
        val oil = Regex("""\boil\b""")
        if (left.isNotEmpty() && cookingFoodForms(wanted).isEmpty() && !oil.containsMatchIn(wanted) && oil.containsMatchIn(seen) ||
            right.isNotEmpty() && cookingFoodForms(seen).isEmpty() && !oil.containsMatchIn(seen) && oil.containsMatchIn(wanted)) return true
        if (left.isEmpty()) return false
        if (right.isEmpty()) {
            // Preserve recognised bare beef-cut aliases, without treating a bare
            // breast/rump/fillet as proof of an otherwise missing species.
            return !(left == setOf("beef") && Regex("""\b(sirloin|scotch fillet|eye fillet|oyster blade)\b""").containsMatchIn(seen))
        }
        return left.any { requested -> right.none { compatibleProtein(requested, it) } } ||
            right.any { offered -> left.none { compatibleProtein(it, offered) } }
    }

    private fun breedOf(canonical: String): String = when {
        Regex("""\bwagyu\b""").containsMatchIn(canonical) -> "wagyu"
        Regex("""\bangus\b""").containsMatchIn(canonical) -> "angus"
        else -> "ordinary"
    }

    private fun boneStyle(canonical: String): String? {
        val boneIn = Regex("""\b(bone in|on the bone|cutlet)\b""").containsMatchIn(canonical)
        val boneless = Regex("""\b(boneless|skinless|fillet)\b""").containsMatchIn(canonical)
        return when {
            boneIn && !boneless -> "bone-in"
            boneless && !boneIn -> "boneless"
            else -> null
        }
    }

    private fun cutsConflict(left: Set<String>, right: Set<String>): Boolean {
        if (left.isEmpty() || right.isEmpty()) return false
        if (left.none { it in right }) return true
        if (("mince" in left) != ("mince" in right)) return true
        if (("liver" in left) != ("liver" in right)) return true
        if (("whole" in left) != ("whole" in right)) return true
        return false
    }

    private fun stockFlag(inStock: Boolean?, available: Boolean?): String = when {
        inStock == true && available == true -> "IN_STOCK"
        inStock == false && available == false -> "OUT_OF_STOCK"
        else -> "UNKNOWN"
    }

    fun searchPhrases(query: String): List<String> {
        val primary = query.replace(Regex("""\s+"""), " ").trim()
        if (primary.length < 2) return emptyList()
        val folded = primary.lowercase(Locale.US)
        val phrases = mutableListOf(primary.take(80))
        var best: MeatCut? = null
        var bestLen = 0
        var ties = 0
        for (entry in MeatCuts.all) {
            for (name in listOf(entry.shoppingName) + entry.aliases) {
                val needle = name.lowercase(Locale.US)
                if (needle.length < 4) continue
                if (folded != needle && !folded.contains(needle)) continue
                if (needle.length > bestLen) {
                    best = entry
                    bestLen = needle.length
                    ties = 1
                } else if (needle.length == bestLen && entry.id != best?.id) {
                    ties += 1
                }
            }
        }
        val chosen = if (ties == 1) best else null
        if (chosen != null) {
            for (alias in chosen.aliases.sortedBy { it.length }) {
                if (phrases.size >= 3) break
                val clean = alias.replace(Regex("""\s+"""), " ").trim()
                if (clean.length !in 6..80) continue
                if (folded.contains(clean.lowercase(Locale.US))) continue
                if (phrases.any { it.equals(clean, ignoreCase = true) }) continue
                phrases += clean
            }
        }
        if (phrases.size < 3) {
            val swaps = listOf(
                Regex("""\bcilantro\b""", RegexOption.IGNORE_CASE) to "coriander",
                Regex("""\bcourgettes?\b""", RegexOption.IGNORE_CASE) to "zucchini",
                Regex("""\bzucchinis?\b""", RegexOption.IGNORE_CASE) to "courgette",
                Regex("""\baubergines?\b""", RegexOption.IGNORE_CASE) to "eggplant",
                Regex("""\beggplants?\b""", RegexOption.IGNORE_CASE) to "aubergine",
                Regex("""\bshrimps?\b""", RegexOption.IGNORE_CASE) to "prawns",
                Regex("""\bprawns?\b""", RegexOption.IGNORE_CASE) to "shrimp",
                Regex("""\bgarbanzo(?: beans?)?\b""", RegexOption.IGNORE_CASE) to "chickpea",
                Regex("""\bchickpeas?\b""", RegexOption.IGNORE_CASE) to "garbanzo",
                Regex("""\byoghurt\b""", RegexOption.IGNORE_CASE) to "yogurt",
                Regex("""\byogurt\b""", RegexOption.IGNORE_CASE) to "yoghurt",
                Regex("""\bbell peppers?\b""", RegexOption.IGNORE_CASE) to "capsicum",
                Regex("""\bcapsicums?\b""", RegexOption.IGNORE_CASE) to "bell pepper",
                Regex("""\bwagu\b""", RegexOption.IGNORE_CASE) to "wagyu"
            )
            for ((pattern, replacement) in swaps) {
                if (phrases.size >= 3) break
                val swapped = pattern.replace(primary, replacement).replace(Regex("""\s+"""), " ").trim()
                if (swapped.length < 2 || swapped.equals(primary, ignoreCase = true)) continue
                if (phrases.any { it.equals(swapped, ignoreCase = true) }) continue
                phrases += swapped.take(80)
            }
        }
        return phrases
    }
}

object WoolworthsCatalogue {
    const val LABEL = "Woolworths online catalogue. Not a confirmed price on the shelf at your local shop, and not a butcher or fruit-shop board."

    fun parse(json: String): ParsedCatalogue {
        val root = try {
            JsonParser.parseString(json)
        } catch (_: Exception) {
            return ParsedCatalogue(emptyList(), null)
        }
        if (!root.isJsonObject) return ParsedCatalogue(emptyList(), null)
        val groups = root.asJsonObject.get("Products")
        if (groups == null || !groups.isJsonArray) return ParsedCatalogue(emptyList(), null)
        val products = mutableListOf<CatalogueProduct>()
        val seen = mutableSetOf<String>()
        var storeId: String? = null
        for (groupEl in groups.asJsonArray) {
            if (!groupEl.isJsonObject) continue
            val group = groupEl.asJsonObject
            val nested = group.get("Products")?.takeIf { it.isJsonArray }?.asJsonArray ?: JsonArray().apply { add(group) }
            for (itemEl in nested) {
                if (!itemEl.isJsonObject) continue
                val row = itemEl.asJsonObject
                val id = text(row, "FulfilmentStoreId")
                if (storeId == null) storeId = id
                val name = text(row, "Name") ?: text(row, "DisplayName") ?: continue
                val stockcode = text(row, "Stockcode")
                val key = stockcode ?: name
                if (!seen.add(key)) continue
                products += CatalogueProduct(
                    name = name,
                    priceCents = priceCents(row),
                    packageSize = text(row, "PackageSize"),
                    inStock = flag(row, "IsInStock"),
                    available = flag(row, "IsAvailable"),
                    url = stockcode?.let { "https://www.woolworths.com.au/shop/productdetails/$it" }
                )
                if (products.size >= 24) return ParsedCatalogue(products, storeId)
            }
        }
        return ParsedCatalogue(products, storeId)
    }

    fun storeNote(store: Store): String {
        val name = store.name.lowercase(Locale.US)
        return when {
            store.chain == StoreChain.LOCAL_BUTCHER || "butcher" in name ->
                "${store.name}: no published board. Ask for the cut by name. A Woolworths catalogue price is not this shop."
            store.chain == StoreChain.LOCAL_GREENGROCER ->
                "${store.name}: no published fruit-and-veg price. Ask in the shop. A supermarket catalogue price is not this shop."
            store.chain == StoreChain.WOOLWORTHS || "woolworths" in name ->
                "${store.name}: Woolworths online catalogue can be checked. That price is not confirmed on the shelf at this store."
            store.chain == StoreChain.COLES || "coles" in name ->
                "${store.name}: Coles blocks an automatic price check. Nothing was invented."
            store.chain == StoreChain.ALDI || Regex("""\baldi\b""").containsMatchIn(name) ->
                "${store.name}: no public price feed. Ask in store."
            else -> "${store.name}: no public price feed. Ask in store, or import the price you saw."
        }
    }

    /** Woolworths' own store list. A petrol site is left out. Distance is straight-line from the stored postcode centre. */
    fun parseStores(json: String, latitude: Double, longitude: Double, radiusKm: Double): List<FoundShop> {
        val root = parseObject(json) ?: return emptyList()
        val stores = root.get("Stores")?.takeIf { it.isJsonArray }?.asJsonArray ?: return emptyList()
        val found = mutableListOf<FoundShop>()
        for (item in stores) {
            if (!item.isJsonObject) continue
            val row = item.asJsonObject
            val division = text(row, "Division")?.uppercase(Locale.US) ?: ""
            if (division != "SUPERMARKETS") continue
            val rawName = text(row, "Name") ?: continue
            if (fuelShop(rawName)) continue
            val lat = number(row, "Latitude") ?: continue
            val lon = number(row, "Longitude") ?: continue
            val km = Postcodes.straightLineKm(latitude, longitude, lat, lon)
            if (km > radiusKm) continue
            val name = if (rawName.contains("woolworths", ignoreCase = true)) rawName else "Woolworths $rawName"
            val detail = listOfNotNull(text(row, "AddressLine1"), text(row, "Suburb"), text(row, "Postcode")).joinToString(", ")
            found += FoundShop(name, "woolworths", detail, km)
        }
        return found
    }

    /** OpenStreetMap shops from a Photon reverse result. Petrol stations are left out. */
    fun parseMapShops(json: String, latitude: Double, longitude: Double, radiusKm: Double): List<FoundShop> {
        val root = parseObject(json) ?: return emptyList()
        val features = root.get("features")?.takeIf { it.isJsonArray }?.asJsonArray ?: return emptyList()
        val allowed = setOf("supermarket", "greengrocer", "butcher", "farm", "grocery")
        val found = mutableListOf<FoundShop>()
        for (item in features) {
            if (!item.isJsonObject) continue
            val feature = item.asJsonObject
            val properties = feature.get("properties")?.takeIf { it.isJsonObject }?.asJsonObject ?: continue
            val geometry = feature.get("geometry")?.takeIf { it.isJsonObject }?.asJsonObject ?: continue
            if (text(geometry, "type") != "Point") continue
            if (text(properties, "osm_key") != "shop") continue
            val osm = text(properties, "osm_value") ?: continue
            if (osm !in allowed) continue
            val name = text(properties, "name") ?: continue
            if (fuelShop(name)) continue
            val coordinates = geometry.get("coordinates")?.takeIf { it.isJsonArray }?.asJsonArray ?: continue
            if (coordinates.size() < 2) continue
            val lon = coordinates[0].takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asDouble ?: continue
            val lat = coordinates[1].takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asDouble ?: continue
            val km = Postcodes.straightLineKm(latitude, longitude, lat, lon)
            if (km > radiusKm) continue
            val detail = listOfNotNull(text(properties, "street"), text(properties, "city"), text(properties, "postcode")).joinToString(", ")
            found += FoundShop(name, kindFor(name, osm), detail, km)
        }
        return found
    }

    fun notesFor(shops: List<FoundShop>): List<String> {
        val kept = mutableListOf<FoundShop>()
        val seen = mutableSetOf<String>()
        for (shop in shops.sortedBy { it.distanceKm }) {
            val key = shop.name.lowercase(Locale.US)
                .replace(Regex("""^woolworths\s+"""), "")
                .replace(Regex("""[^a-z0-9]"""), "")
            if (key.length < 3 || !seen.add(key)) continue
            kept += shop
            if (kept.size >= 16) break
        }
        return kept.map { noteFor(it) }
    }

    fun noteFor(shop: FoundShop): String {
        val place = listOf(shop.name, shop.detail).filter { it.isNotBlank() }.joinToString(", ")
        val km = String.format(Locale.US, "%.1f", shop.distanceKm)
        val body = when (shop.kind) {
            "butcher" -> "no published board. Ask for the cut by name. A Woolworths catalogue price is not this shop."
            "produce" -> "no published fruit-and-veg price. Ask in the shop. A supermarket catalogue price is not this shop."
            "woolworths" -> "Woolworths online catalogue can be checked. That price is not confirmed on the shelf at this store."
            "coles" -> "Coles blocks an automatic price check. Nothing was invented."
            "aldi" -> "no public price feed. Ask in store."
            else -> "no public price feed. Ask in store, or record the price you saw."
        }
        return "$place: $body · $km km straight-line."
    }

    private fun kindFor(name: String, osm: String): String {
        val folded = name.lowercase(Locale.US)
        return when {
            "butcher" in folded || osm == "butcher" -> "butcher"
            osm == "greengrocer" || osm == "farm" || Regex("""\b(fruit|greengrocer|veg)\b""").containsMatchIn(folded) -> "produce"
            "woolworths" in folded -> "woolworths"
            "coles" in folded -> "coles"
            Regex("""\baldi\b""").containsMatchIn(folded) -> "aldi"
            else -> "supermarket"
        }
    }

    private fun fuelShop(name: String): Boolean =
        Regex("""\b(petrol|diesel|fuel|servo|service station|ampol|caltex|shell|mobil|coles express|reddy express|\bbp\b|\botr\b)\b""", RegexOption.IGNORE_CASE)
            .containsMatchIn(name)

    private fun parseObject(json: String): JsonObject? {
        val root = try {
            JsonParser.parseString(json)
        } catch (_: Exception) {
            return null
        }
        return if (root.isJsonObject) root.asJsonObject else null
    }

    private fun number(row: JsonObject, key: String): Double? {
        val value = row.get(key) ?: return null
        if (!value.isJsonPrimitive) return null
        val primitive = value.asJsonPrimitive
        val parsed = when {
            primitive.isNumber -> primitive.asDouble
            primitive.isString -> primitive.asString.toDoubleOrNull()
            else -> null
        }
        return parsed?.takeIf { it.isFinite() }
    }

    private fun priceCents(row: JsonObject): Long? {
        val price = row.get("Price")
        val parsed = if (price != null && price.isJsonPrimitive && price.asJsonPrimitive.isNumber) {
            CatalogueMoney.audToCents(price.asDouble)
        } else null
        if (parsed != null) return parsed
        if (price == null || price.isJsonNull) {
            val instore = row.get("InstorePrice")
            if (instore != null && instore.isJsonPrimitive && instore.asJsonPrimitive.isNumber) {
                return CatalogueMoney.audToCents(instore.asDouble)
            }
        }
        return null
    }

    private fun flag(row: JsonObject, key: String): Boolean? {
        val value = row.get(key) ?: return null
        if (!value.isJsonPrimitive || !value.asJsonPrimitive.isBoolean) return null
        return value.asBoolean
    }

    private fun text(row: JsonObject, key: String): String? {
        val value = row.get(key) ?: return null
        if (!value.isJsonPrimitive) return null
        val primitive = value.asJsonPrimitive
        val text = when {
            primitive.isString -> primitive.asString.trim()
            primitive.isNumber -> primitive.asString
            else -> return null
        }
        return text.ifBlank { null }
    }
}
