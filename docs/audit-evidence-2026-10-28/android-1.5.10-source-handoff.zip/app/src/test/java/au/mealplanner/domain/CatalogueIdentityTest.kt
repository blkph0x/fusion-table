package au.mealplanner.domain

import au.mealplanner.domain.shopping.CatalogueProduct
import au.mealplanner.domain.shopping.ProductMatcher
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CatalogueIdentityTest {
    private fun product(name: String) = CatalogueProduct(name, 500L, "500g", true, true, null)
    private fun selected(query: String, name: String, pack: String = "500g") = ProductMatcher.match(query, listOf(product(name).copy(packageSize = pack))).any { it.selected }
    private fun excluded(query: String, name: String, pack: String = "500g") = assertTrue("$query must exclude $name", ProductMatcher.match(query, listOf(product(name).copy(packageSize = pack))).isEmpty())

    @Test
    fun animalMinceCannotUsePlantBasedSubstitutes() {
        excluded("Beef mince", "Plant Based Beef Mince")
        excluded("Raw beef mince", "Plant Based Beef Mince 500g")
        excluded("Chicken mince", "Meat Free Chicken Mince")
        excluded("Plant Based Beef Mince", "Raw Beef Mince")
        excluded("Beef mince", "Quorn Mince")
        excluded("Plant based mince", "Quorn Mince")
        excluded("Vegan mince", "Vegetarian Mince")
        assertTrue(selected("Beef mince", "Lean Beef Mince 500g"))
        assertTrue(selected("Plant Based Beef Mince", "Plant Based Beef Mince 500g"))
        assertTrue(selected("Plant based mince", "Plant Based Beef Mince"))
        assertTrue(selected("Vegan mince", "Vegan Plant Based Mince"))
        assertTrue(selected("Angus beef mince", "Angus Mince"))
    }

    @Test
    fun butterAndDairyKeepTheirActualFoodType() {
        excluded("Unsalted butter", "Organic Peanut Butter Unsalted")
        excluded("Butter", "Peanut Butter Smooth")
        excluded("Milk", "Soy Milk")
        excluded("Cooking cream", "Coconut Cooking Cream")
        excluded("Almond milk", "Oat Milk")
        excluded("Vegan butter", "Vegan Peanut Butter")
        assertTrue(selected("Unsalted butter", "Unsalted Butter Block"))
        assertTrue(selected("Peanut butter", "Organic Peanut Butter Smooth"))
        assertTrue(selected("Almond milk", "Unsweetened Almond Milk"))
        assertTrue(selected("Coconut cooking cream", "Coconut Cooking Cream"))
        assertTrue(selected("Vegan butter", "Vegan Butter Spread"))
        assertTrue(selected("Dairy-free butter", "Dairy Free Butter Spread"))
        assertTrue(selected("Lactose-free milk", "Lactose Free Full Cream Milk"))
    }

    @Test
    fun cookedAndDeliPoultryCannotPriceRawBreast() {
        for (name in listOf("Cooked Chicken Breast Fillets", "Carved Roast Chicken Breast", "Shredded Chicken Breast Deli Slices", "Shredded Roast Chicken", "Chicken Breast Thinly Sliced")) excluded("Chicken breast", name)
        assertTrue(selected("Chicken breast", "Fresh Chicken Breast Fillets"))
        assertTrue(selected("Chicken breast", "Raw Chicken Breast Slices For Stir Fry"))
        assertTrue(selected("Cooked chicken breast", "Carved Roast Chicken Breast Deli Slices"))
        assertTrue(selected("Cooked chicken breast", "Cooked Chicken Breast Fillets"))
    }

    @Test
    fun aWholePoultryCutDoesNotProveARoastIsRaw() {
        excluded("Whole chicken", "Hot Roast Whole Chicken")
        excluded("Whole chicken", "Roast Whole Chicken")
        excluded("Whole turkey", "Whole Turkey Roast")
        excluded("Whole chicken", "Fresh Hot Roast Whole Chicken")
        excluded("Whole turkey", "Fresh Hot Whole Turkey Roast")
        excluded("Chicken breast", "Fresh Carved Roast Chicken Breast")
        assertTrue(selected("Whole chicken", "Fresh Whole Chicken"))
        assertTrue(selected("Whole chicken", "Fresh Roasting Whole Chicken"))
        assertTrue(selected("Whole turkey", "Whole Turkey For Roasting"))
        assertTrue(selected("Whole turkey", "Raw Whole Turkey Roast"))
        assertTrue(selected("Cooked whole turkey", "Whole Turkey Roast"))
        assertTrue(selected("Cooked whole chicken", "Fresh Hot Roast Whole Chicken"))
    }

    @Test
    fun rawRoastingCutsAndExplicitPreparedFoodsRemainAvailable() {
        assertTrue(selected("Beef bolar roast", "Beef Bolar Roast"))
        assertTrue(selected("Pork leg roast", "Pork Leg Roast"))
        assertTrue(selected("Chicken breast", "Chicken Breast Roasting Joint"))
        assertTrue(selected("Chicken stock", "Roast Chicken Stock"))
        excluded("Chicken breast", "Crumbed Chicken Breast Schnitzel")
        assertTrue(selected("Crumbed chicken breast schnitzel", "Crumbed Chicken Breast Schnitzel"))
        assertTrue(selected("Smoked chicken breast", "Smoked Chicken Breast Slices"))
    }

    @Test
    fun anIngredientHeadCannotBeLostAmongQuantityTokens() {
        excluded("Brown onion 180g", "Brown Rice 1kg")
        excluded("Brown onion", "Brown Rice")
        assertTrue(selected("Brown onion 180g", "Brown Onion Loose"))
        assertTrue(selected("Brown onion 180 g", "Brown Onions"))
        assertTrue(selected("Fresh coriander", "Fresh Coriander"))
        assertTrue(selected("Beef sirloin", "Porterhouse Steak"))
    }

    @Test
    fun aromaticsAndProduceCannotBeReplacedByFinishedFoodsOrPreparedJars() {
        excluded("Fresh ginger", "Stem Ginger Cookies")
        excluded("Fresh ginger", "Stem Ginger Biscuits")
        excluded("Fresh garlic", "Garlic Bread")
        excluded("Fresh basil", "Basil Pesto")
        excluded("Tomatoes", "Tomato Relish")
        excluded("Lime juice", "Lime Juice Cordial")
        excluded("Fresh ginger", "Ginger Beer")
        excluded("Fresh ginger", "Ginger In Syrup")
        excluded("Fresh ginger", "Buderim Ginger Australian Ready Cut")
        excluded("Fresh ginger", "Jensens Crushed Ginger")
        excluded("Fresh ginger", "MasterFoods Finely Chopped Ginger")
        assertTrue(selected("Fresh ginger", "Fresh Chopped Ginger"))
        assertTrue(selected("Garlic", "Fresh Garlic Cloves"))
        assertTrue(selected("Crushed ginger", "Jensens Crushed Ginger"))
        assertTrue(selected("Chopped ginger", "MasterFoods Finely Chopped Ginger"))
    }

    @Test
    fun explicitlyRequestedPreparedFoodsSeedsAndFoodFormsRemainAvailable() {
        assertTrue(selected("Ginger cookies", "Stem Ginger Cookies"))
        assertTrue(selected("Garlic bread", "Garlic Butter Bread"))
        assertTrue(selected("Basil pesto", "Basil Pesto"))
        assertTrue(selected("Lime juice cordial", "Lime Juice Cordial"))
        assertTrue(selected("Ginger beer", "Ginger Beer"))
        assertTrue(selected("Ground ginger", "Ground Ginger"))
        assertTrue(selected("Garlic paste", "Garlic Paste"))
        assertTrue(selected("Sesame seeds", "Sesame Seeds"))
        assertTrue(selected("Coriander seeds", "Coriander Seeds"))
        assertTrue(selected("Cream of tartar", "Cream Of Tartar"))
        assertTrue(selected("Arborio risotto rice", "Arborio Risotto Rice"))
    }

    @Test
    fun clearNonFoodListingsCannotPriceIngredientsButCulinarySeedsAndOilsStayAvailable() {
        excluded("Fresh ginger", "Dr Scent Ginger Lemongrass Aroma Oil - Fresh Strong Herbal - Waterless Diffuser Oil 1000ml")
        excluded("Spring onions", "Yates Spring Onions Seeds")
        excluded("Spring onions", "Stainless Steel Cutter Gadget Scallion Vegetable Spring Onion Slicer")
        excluded("Coconut oil", "Coconut Hair Oil")
        excluded("Milk", "Milk Body Lotion")
        excluded("Chicken", "Chicken Dog Food")
        excluded("Coriander seeds", "Coriander Seeds For Planting")
        excluded("Chicken", "Chicken Wire Mesh")
        assertTrue(selected("Sesame seeds", "Sesame Seeds"))
        assertTrue(selected("Coriander seeds", "Coriander Seeds"))
        assertTrue(selected("Pumpkin seeds", "Pumpkin Seeds"))
        assertTrue(selected("Spring onions", "Fresh Spring Onions Bunch"))
        assertTrue(selected("Olive oil", "Extra Virgin Olive Oil"))
        assertTrue(selected("Coconut oil", "Virgin Coconut Oil"))
    }

    @Test
    fun sweetPotatoAndOrdinaryPotatoesKeepTheirIdentity() {
        excluded("Potatoes", "Sweet Potatoes")
        excluded("White potatoes", "Sweet Potatoes")
        excluded("Sweet potatoes", "White Potatoes")
        assertTrue(selected("Potatoes", "White Potatoes"))
        assertTrue(selected("Potatoes", "Baby Potatoes"))
        assertTrue(selected("Sweet potatoes", "Sweet Potatoes"))
    }

    @Test
    fun compoundButtersCannotReplacePlainButterOrLoseTheirFlavours() {
        excluded("Unsalted butter", "Unsalted Garlic Butter")
        excluded("Butter", "Herb Butter")
        excluded("Garlic butter", "Butter Block")
        excluded("Herb butter", "Butter Block")
        excluded("Garlic butter", "Garlic And Herb Butter")
        assertTrue(selected("Butter", "Unsalted Butter Block"))
        assertTrue(selected("Garlic butter", "Garlic Butter"))
        assertTrue(selected("Herb butter", "Herb Butter"))
        assertTrue(selected("Garlic and herb butter", "Garlic And Herb Butter"))
        assertTrue(selected("Garlic bread", "Garlic Butter Bread"))
        assertTrue(selected("Peanut butter", "Peanut Butter Smooth"))
        assertTrue(selected("Vegan butter", "Vegan Butter Spread"))
    }

    @Test
    fun gingerFlavouredBreadCompoundsCannotPriceFreshGinger() {
        excluded("Fresh ginger", "CURATED COLLECTION Gluten Free Fig and Ginger Crispbread 150g")
        excluded("Fresh ginger", "Gingerbread")
        excluded("Fresh ginger", "Ginger Shortbread")
        assertTrue(selected("Gingerbread biscuits", "Gingerbread Biscuits"))
        assertTrue(selected("Fresh ginger", "Fresh Ginger Root"))
    }

    @Test
    fun poultryFilletsCannotUseBuffeCrownOrUnrequestedSelfBastingPreparations() {
        for (name in listOf("Ingham's Frozen Buffe Turkey Breast Self Basting", "Turkey Breast Crown", "Turkey Breast Buffet", "Self Basting Turkey Breast Fillets", "Self Basted Turkey Breast Fillets", "Injected Turkey Breast Fillets")) {
            excluded("Turkey breast fillets", name)
        }
        excluded("Chicken breast fillets", "Chicken Breast Crown")
        assertTrue(selected("Turkey breast fillets", "Fresh Turkey Breast Fillets"))
        assertTrue(selected("Self basting turkey breast", "Brand Self Basting Turkey Breast"))
        assertTrue(selected("Self basted turkey breast", "Brand Self Basted Turkey Breast"))
        assertTrue(selected("Turkey breast buffe", "Turkey Breast Buffe"))
        assertTrue(selected("Self basting turkey breast buffe", "Ingham's Frozen Buffe Turkey Breast Self Basting"))
    }

    @Test
    fun turkeyBreastCannotUseTheCapturedDuckBreastProduct() {
        excluded("Turkey breast fillets", "Luv-A-Duck Fresh Duck Breast Fillets")
        assertTrue(selected("Turkey breast fillets", "Fresh Turkey Breast Fillets"))
        assertTrue(selected("Duck breast fillets", "Luv-A-Duck Fresh Duck Breast Fillets"))
    }

    @Test
    fun everyAuthoredMainKeepsItsIdentityAcrossTheOtherTwentyNineMains() {
        val mains = listOf(
            "Chicken breast fillets", "Turkey breast fillets", "Beef rump steak", "Lamb leg steak", "Pork loin steak",
            "Salmon fillets", "White fish fillets", "Raw prawns", "Firm tofu", "Plain tempeh", "Halloumi", "Eggs",
            "Cooked chickpeas", "Cooked green lentils", "Canned butter beans", "Portobello mushrooms", "Aubergine",
            "Cauliflower", "Pumpkin", "Sweet potato", "Courgette", "Broccoli", "Duck breast fillets", "Kangaroo steak",
            "Tuna steak", "Fresh sardines", "Canned black beans", "Canned red kidney beans", "Young jackfruit", "Paneer cheese"
        )
        assertEquals(30, mains.size)
        for (wanted in mains) {
            assertTrue("A plain same-main product must stay available: $wanted", selected(wanted, "Brand $wanted"))
            for (other in mains.filter { it != wanted }) excluded(wanted, "Brand $other")
        }
    }

    @Test
    fun whiteFishUsesOnlyTheAuthoredAliasesAndNamedSpeciesStaySpecific() {
        for (name in listOf("Cod", "Hoki", "Barramundi", "Haddock", "Pollock", "Hake", "Basa")) {
            assertTrue("White fish must allow the authored alias $name", selected("White fish fillets", "$name Fillets"))
            assertTrue(selected("Fish fillets", "$name Fillets"))
        }
        for (name in listOf("Salmon Fillets", "Tuna Fillets", "Sardine Fillets", "Prawn Fillets")) excluded("White fish fillets", name)
        excluded("Cod fillets", "Hoki Fillets")
        excluded("Cod fillets", "White Fish Fillets")
        excluded("Cod fillets", "Fish Fillets")
        excluded("Fish fillets", "Prawn Fillets")
        assertTrue(selected("White fish", "Cod"))
        assertTrue(selected("Cod fillets", "Atlantic Cod Fillets"))
        assertTrue(selected("Prawns", "Raw Shrimp"))
    }

    @Test
    fun namedProteinsCannotBeLostBehindAnUnnamedOrMixedCut() {
        excluded("Turkey breast fillets", "Breast Fillets")
        excluded("Duck breast fillets", "Chicken Breast Fillets")
        excluded("Beef rump steak", "Kangaroo Rump Steak")
        excluded("Beef mince", "Veal Mince")
        excluded("Turkey breast fillets", "Turkey And Duck Breast Fillets")
        excluded("Firm tofu", "Firm Tofu And Tempeh")
        excluded("Plant based beef mince", "Plant Based Chicken Mince")
        assertTrue(selected("Veal mince", "Fresh Veal Mince"))
        assertTrue(selected("Beef mince", "Lean Beef Mince"))
        assertTrue(selected("Tofu", "Bean Curd"))
        assertTrue(selected("Butter beans", "Lima Beans"))
    }

    @Test
    fun brandAndCutWordsDoNotInventAnimalSpecies() {
        assertTrue(selected("Chicken breast fillets", "Luv-A-Duck Fresh Chicken Breast Fillets"))
        excluded("Duck breast fillets", "Luv-A-Duck Fresh Chicken Breast Fillets")
        assertTrue(selected("Beef sirloin", "Porterhouse Steak"))
        assertTrue(selected("Beef scotch fillet", "Cube Roll"))
        assertTrue(selected("Beef oyster blade", "Flat Iron Steak"))
        assertTrue(selected("Oyster blade", "Beef Oyster Blade"))
        assertTrue(selected("Oyster mushrooms", "King Oyster Mushrooms"))
        excluded("Oysters", "Beef Oyster Blade")
        excluded("Oysters", "King Oyster Mushrooms")
    }

    @Test
    fun eggAndDairyNamesDoNotInventMeatSpecies() {
        assertTrue(selected("Eggs", "Free Range Chicken Eggs"))
        excluded("Eggs", "Free Range Duck Eggs")
        excluded("Duck eggs", "Free Range Chicken Eggs")
        excluded("Duck breast", "Duck Eggs")
        assertTrue(selected("Duck eggs", "Free Range Duck Eggs"))
        assertTrue(selected("Quail eggs", "Quail Eggs"))
        assertTrue(selected("Goat milk", "Goat Milk"))
        assertTrue(selected("Milk", "Full Cream Goat Milk"))
        excluded("Goat meat", "Goat Milk")
    }

    @Test
    fun stocksOilsAndTheSquidSauceBrandKeepTheirActualFoodForm() {
        excluded("Salmon fillets", "Salmon Oil")
        excluded("Tofu", "Tofu Oil")
        excluded("Fish oil", "Raw Fish")
        assertTrue(selected("Fish oil", "Fish Oil"))
        assertTrue(selected("Chicken stock", "Roast Chicken Stock"))
        assertTrue(selected("Fish sauce", "Squid Fish Sauce"))
        assertTrue(selected("Fish sauce", "Squid Brand Fish Sauce"))
        excluded("Squid", "Squid Brand Fish Sauce")
    }

    @Test
    fun tortillaFoodCannotBePricedUsingTheCapturedTacoHolder() {
        excluded("Soft tortillas", "JOYBUY Stainless Steel Taco Holders for Soft or Hard Tacos, Burritos and Tortillas (1 Pack)")
        excluded("Tortillas", "Silicone Taco Stand For Tortillas")
        assertTrue(selected("Soft tortillas", "Mission Soft Tortillas"))
        assertTrue(selected("Carrots", "Fresh Carrots Tray"))
    }

    @Test
    fun aSingleFreshCarrotCannotUseMixedFrozenOrRoastVegetablePacks() {
        for (name in listOf(
            "MARKET FARE Carrot, Sweet Corn & Broccoli Quicksteam Vegetables 3 Pack 450g",
            "MARKET FARE Peas, Carrots & Super Sweet Corn 1kg",
            "MARKET FARE Quicksteam Vegetables Carrot, Broccoli & Cauliflower 3 Pack 450g",
            "Birds Eye Country Harvest Carrot Cauliflower Beans & Broccoli",
            "Birds Eye Country Harvest Peas Corn & Carrot",
            "Birds Eye Deli Roast Veggies Potato Pumpkin Onion Carrot",
            "Frozen Carrots"
        )) excluded("Carrot", name)
        excluded("Frozen carrots", "Fresh Carrots")
        assertTrue(selected("Carrots", "Macro Organic Carrots"))
        assertTrue(selected("Carrots", "Woolworths Australian Grown Carrots"))
        assertTrue(selected("Frozen carrots", "Frozen Carrots"))
        assertTrue(selected("Roasted carrots", "Oven Roasted Carrots"))
        assertTrue(selected("Potatoes", "Fresh Roasting Potatoes"))
        assertTrue(selected("Mixed frozen vegetables", "Mixed Frozen Vegetables"))
    }

    @Test
    fun tinyGenericHerbPacksRemainUncertainWithoutFreshFormEvidence() {
        excluded("Coriander leaves for the side", "MasterFoods Coriander Leaves", "5g")
        excluded("Fresh coriander", "MasterFoods Coriander Leaves", "0.005 kg")
        excluded("Basil leaves", "Basil Leaves", "2 x 5g")
        excluded("Parsley leaves", "Parsley Leaves", "5g x 2")
        assertTrue(selected("Fresh coriander", "Fresh Coriander Leaves", "5g"))
        assertTrue(selected("Coriander leaves", "Coriander Leaves Bunch", "5g"))
        assertTrue(selected("Basil leaves", "Living Basil Leaves Pot", "5g"))
        assertTrue(selected("Coriander leaves", "Coriander Leaves", "15g"))
        assertTrue(selected("Dried coriander leaves", "Dried Coriander Leaves", "5g"))
        assertTrue(selected("Coriander seeds", "Coriander Seeds", "5g"))
    }

    @Test
    fun uncertainOrUnavailableStockStillCannotSupplyAnAutomaticPrice() {
        for (candidate in listOf(product("Chicken Breast Fillets").copy(inStock = null, available = null), product("Chicken Breast Fillets").copy(inStock = false, available = false))) {
            val matches = ProductMatcher.match("Chicken breast", listOf(candidate))
            assertEquals(1, matches.size)
            assertFalse(matches.single().selected)
        }
    }
}
